#ifndef IDE_H
#define IDE_H

#include "types.h"

// IDE ports (Primary IDE)
#define IDE_DATA        0x1F0
#define IDE_ERROR       0x1F1
#define IDE_FEATURES    0x1F1
#define IDE_SECTOR_CNT  0x1F2
#define IDE_LBA_LOW     0x1F3
#define IDE_LBA_MID     0x1F4
#define IDE_LBA_HIGH    0x1F5
#define IDE_DRIVE       0x1F6
#define IDE_STATUS      0x1F7
#define IDE_COMMAND     0x1F7

// IDE status bits
#define IDE_STATUS_BSY  0x80    // Busy
#define IDE_STATUS_DRDY 0x40    // Drive ready
#define IDE_STATUS_DF   0x20    // Drive fault
#define IDE_STATUS_DSC  0x10    // Drive seek complete
#define IDE_STATUS_DRQ  0x08    // Data request ready
#define IDE_STATUS_CORR 0x04    // Corrected data
#define IDE_STATUS_IDX  0x02    // Index
#define IDE_STATUS_ERR  0x01    // Error

// IDE commands
#define IDE_CMD_READ_SECTORS    0x20
#define IDE_CMD_WRITE_SECTORS   0x30
#define IDE_CMD_IDENTIFY        0xEC

// IDE functions
void ide_init(void);
void ide_read_sectors(uint32_t lba, uint8_t count, uint16_t* buffer);
void ide_write_sectors(uint32_t lba, uint8_t count, uint16_t* buffer);
void ide_wait_ready(void);
void ide_poll(void);

#endif // IDE_H
