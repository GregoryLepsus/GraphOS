#ifndef VFS_CACHE_H
#define VFS_CACHE_H

#include <stdint.h>
#include "vfs.h"

// Cache Entry
typedef struct {
    char path[256];
    vfs_node_t* node;
    uint32_t access_count;
    uint8_t valid;
} vfs_cache_entry_t;

// Cache Functions
void vfs_cache_init(void);
int vfs_cache_add(const char* path, vfs_node_t* node);
vfs_node_t* vfs_cache_lookup(const char* path);
void vfs_cache_invalidate(const char* path);

#endif // VFS_CACHE_H
