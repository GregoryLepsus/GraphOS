#ifndef IDT_H
#define IDT_H

#include "types.h"

// Структура одного дескриптора IDT
struct idt_entry {
    uint16_t base_low;   // Младшие 16 бит адреса обработчика
    uint16_t selector;   // Селектор сегмента кода
    uint8_t  always0;    // Всегда 0
    uint8_t  flags;      // Флаги типа и атрибутов
    uint16_t base_high;  // Старшие 16 бит адреса обработчика
} __attribute__((packed));

// Указатель на IDT для команды LIDT
struct idt_ptr {
    uint16_t limit;      // Размер IDT - 1
    uint32_t base;       // Адрес начала IDT
} __attribute__((packed));

// Флаги для IDT entry
#define IDT_FLAG_PRESENT      0x80  // Дескриптор присутствует
#define IDT_FLAG_RING0        0x00  // Уровень привилегий 0 (kernel)
#define IDT_FLAG_RING3        0x60  // Уровень привилегий 3 (user)
#define IDT_FLAG_GATE_32INT   0x0E  // 32-bit interrupt gate
#define IDT_FLAG_GATE_32TRAP  0x0F  // 32-bit trap gate

// Функции для работы с IDT
void init_idt(void);
void idt_set_gate(uint8_t num, uint32_t base, uint16_t selector, uint8_t flags);

#endif // IDT_H
