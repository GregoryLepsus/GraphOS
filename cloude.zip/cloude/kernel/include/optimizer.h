#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include <stdint.h>
#include <stdbool.h>

// Hot path optimization flags
#define OPT_INLINE          (1 << 0)
#define OPT_CACHE_ALIGN     (1 << 1)
#define OPT_PREFETCH        (1 << 2)
#define OPT_LOOP_UNROLL     (1 << 3)
#define OPT_BRANCH_PREDICT  (1 << 4)

// Performance counters
typedef struct {
    const char* name;
    uint64_t call_count;
    uint64_t total_cycles;
    uint64_t min_cycles;
    uint64_t max_cycles;
    uint32_t flags;
} perf_counter_t;

// Optimization statistics
typedef struct {
    uint32_t total_optimizations;
    uint32_t cache_hits;
    uint32_t cache_misses;
    uint32_t branch_mispredicts;
    uint64_t cycles_saved;
} opt_stats_t;

// Function declarations
void optimizer_init(void);
void optimizer_register_hotpath(const char* name, uint32_t flags);
void optimizer_mark_start(const char* name);
void optimizer_mark_end(const char* name);
void optimizer_report(void);
opt_stats_t* optimizer_get_stats(void);

// Cache optimization helpers
#define CACHE_LINE_SIZE 64
#define CACHE_ALIGN __attribute__((aligned(CACHE_LINE_SIZE)))
#define LIKELY(x)   __builtin_expect(!!(x), 1)
#define UNLIKELY(x) __builtin_expect(!!(x), 0)
#define PREFETCH(addr) __builtin_prefetch(addr, 0, 3)

// Force inline for critical functions
#define FORCE_INLINE static inline __attribute__((always_inline))

// Hot path macro
#define HOT_PATH __attribute__((hot))

// Cold path macro (error handling, etc)
#define COLD_PATH __attribute__((cold))

#endif // OPTIMIZER_H
