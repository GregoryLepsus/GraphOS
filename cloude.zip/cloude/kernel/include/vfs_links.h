#ifndef VFS_LINKS_H
#define VFS_LINKS_H

#include <stdint.h>
#include "vfs.h"

// Symbolic Link
typedef struct symlink {
    char linkpath[256];
    char target[256];
    struct symlink* next;
} symlink_t;

// Hard Link
typedef struct hardlink {
    char linkpath[256];
    vfs_node_t* target;
    uint32_t refcount;
    struct hardlink* next;
} hardlink_t;

// Symbolic Link Functions
int vfs_symlink_create(const char* target, const char* linkpath);
const char* vfs_symlink_resolve(const char* path);
int vfs_symlink_remove(const char* linkpath);

// Hard Link Functions
int vfs_hardlink_create(vfs_node_t* target, const char* linkpath);
vfs_node_t* vfs_hardlink_resolve(const char* path);
int vfs_hardlink_remove(const char* linkpath);

#endif // VFS_LINKS_H
