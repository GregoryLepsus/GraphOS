#ifndef SYNC_H
#define SYNC_H

#include "types.h"

// ============================================================================
// Spinlock
// ============================================================================
typedef struct {
    volatile uint32_t locked;
} spinlock_t;

void spinlock_init(spinlock_t* lock);
void spinlock_acquire(spinlock_t* lock);
void spinlock_release(spinlock_t* lock);
bool spinlock_try_acquire(spinlock_t* lock);

// ============================================================================
// Mutex
// ============================================================================
typedef struct {
    volatile uint32_t locked;
    uint32_t owner_pid;
} mutex_t;

void mutex_init(mutex_t* mutex);
void mutex_lock(mutex_t* mutex);
void mutex_unlock(mutex_t* mutex);
bool mutex_try_lock(mutex_t* mutex);

// ============================================================================
// Semaphore
// ============================================================================
typedef struct {
    volatile int32_t value;
    spinlock_t lock;
} semaphore_t;

void semaphore_init(semaphore_t* sem, int32_t initial_value);
void semaphore_wait(semaphore_t* sem);
void semaphore_signal(semaphore_t* sem);
bool semaphore_try_wait(semaphore_t* sem);
int32_t semaphore_get_value(semaphore_t* sem);

#endif // SYNC_H
