#ifndef MEMORY_OPTIMIZER_H
#define MEMORY_OPTIMIZER_H

#include <stdint.h>

// Memory Statistics
typedef struct {
    uint32_t pages_allocated;
    uint32_t pages_freed;
    uint32_t heap_allocated;
    uint32_t heap_freed;
    uint32_t fragmentation;
    uint32_t compaction_count;
} mem_stats_t;

// Memory Optimizer Functions
void memopt_init(void);
void memopt_update_stats(void);
void memopt_get_stats(mem_stats_t* stats);
int memopt_compact_heap(void);
void memopt_optimize(void);
int memopt_is_low_memory(void);

#endif // MEMORY_OPTIMIZER_H
