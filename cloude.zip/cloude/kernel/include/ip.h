#ifndef IP_H
#define IP_H

#include <stdint.h>

// IP version
#define IP_VERSION 4

// IP header length (5 words = 20 bytes)
#define IP_HLEN 5

// IP protocols
#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP  6
#define IP_PROTO_UDP  17

// IP flags
#define IP_FLAG_DONT_FRAGMENT 0x4000
#define IP_FLAG_MORE_FRAGMENTS 0x2000

// IP header
typedef struct {
    uint8_t version_ihl;     // Version (4 bits) + IHL (4 bits)
    uint8_t tos;             // Type of Service
    uint16_t total_length;
    uint16_t identification;
    uint16_t flags_offset;   // Flags (3 bits) + Fragment Offset (13 bits)
    uint8_t ttl;
    uint8_t protocol;
    uint16_t checksum;
    uint32_t src_ip;
    uint32_t dest_ip;
} __attribute__((packed)) ip_header_t;

// Functions
void ip_init(void);
void ip_set_address(uint32_t ip, uint32_t netmask, uint32_t gateway);
int ip_send(uint32_t dest_ip, uint8_t protocol, uint8_t* data, uint32_t len);
void ip_receive(uint8_t* packet, uint32_t len);
uint16_t ip_checksum(uint16_t* data, int len);

#endif // IP_H
