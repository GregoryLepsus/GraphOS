#ifndef WIDGET_H
#define WIDGET_H

#include <stdint.h>
#include "window.h"

// Widget types
typedef enum {
    WIDGET_BUTTON,
    WIDGET_LABEL,
    WIDGET_TEXTBOX,
    WIDGET_CHECKBOX,
    WIDGET_SCROLLBAR,
    WIDGET_PANEL
} widget_type_t;

// Widget base structure
typedef struct widget {
    widget_type_t type;
    int x, y;
    int width, height;
    int visible;
    int enabled;
    int hovered;
    void* data;
    void (*on_click)(struct widget* w);
    void (*on_draw)(struct widget* w, window_t* win);
    struct widget* next;
} widget_t;

// Button widget data
typedef struct {
    char label[32];
    int pressed;
} button_data_t;

// Label widget data
typedef struct {
    char text[128];
    uint32_t color;
} label_data_t;

// Textbox widget data
typedef struct {
    char text[256];
    int cursor_pos;
    int max_length;
} textbox_data_t;

// Checkbox widget data
typedef struct {
    char label[32];
    int checked;
} checkbox_data_t;

// Widget colors
#define WIDGET_COLOR_BUTTON_BG       0x08
#define WIDGET_COLOR_BUTTON_FG       0x0F
#define WIDGET_COLOR_BUTTON_PRESSED  0x07
#define WIDGET_COLOR_LABEL_FG        0x0F
#define WIDGET_COLOR_TEXTBOX_BG      0x0F
#define WIDGET_COLOR_TEXTBOX_FG      0x00
#define WIDGET_COLOR_BORDER          0x07

// Functions
widget_t* widget_create_button(const char* label, int x, int y, int w, int h, void (*on_click)(widget_t*));
widget_t* widget_create_label(const char* text, int x, int y, uint32_t color);
widget_t* widget_create_textbox(int x, int y, int w, int h);
widget_t* widget_create_checkbox(const char* label, int x, int y, int checked);
void widget_destroy(widget_t* widget);
void widget_draw(widget_t* widget, window_t* win);
int widget_handle_click(widget_t* widget, int x, int y);
widget_t* widget_at_position(widget_t* list, int x, int y);

#endif // WIDGET_H
