#ifndef THREAD_H
#define THREAD_H

#include <stdint.h>
#include "process.h"

// Thread States
#define THREAD_STATE_READY    0
#define THREAD_STATE_RUNNING  1
#define THREAD_STATE_BLOCKED  2
#define THREAD_STATE_DEAD     3

// Thread Structure
typedef struct thread {
    uint32_t tid;              // Thread ID
    uint32_t pid;              // Parent process ID
    uint32_t state;            // Thread state
    uint32_t priority;         // Priority (0-7)
    uint8_t cpu_affinity;      // CPU affinity

    // CPU context
    cpu_context_t context;

    // Stack
    void* kernel_stack;
    void* user_stack;
    uint32_t stack_size;

    // Thread-local storage
    void* tls;

    // Synchronization
    void* wait_object;
    uint32_t sleep_until;

    // Exit status
    int exit_status;

    // Linked list
    struct thread* next;
    struct thread* prev;
} thread_t;

// Thread Functions
void thread_init(void);
thread_t* thread_create(void* entry_point, void* arg, uint32_t priority);
thread_t* thread_create_kernel(void* entry_point, void* arg);
void thread_exit(int status);
void thread_yield(void);
int thread_join(thread_t* thread, int* status);
void thread_sleep(uint32_t ms);
thread_t* thread_get_current(void);
void thread_set_affinity(thread_t* thread, uint8_t cpu_id);

#endif // THREAD_H
