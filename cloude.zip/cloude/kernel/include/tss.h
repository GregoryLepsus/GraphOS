#ifndef TSS_H
#define TSS_H

#include <stdint.h>

// Task State Segment (TSS) для x86
// Используется для переключения между Ring 0 (kernel) и Ring 3 (user)
typedef struct {
    uint32_t prev_tss;   // Предыдущий TSS (для аппаратного переключения задач)
    uint32_t esp0;       // Стек ядра (Ring 0)
    uint32_t ss0;        // Сегмент стека ядра
    uint32_t esp1;       // Стек Ring 1 (не используется)
    uint32_t ss1;        // Сегмент Ring 1
    uint32_t esp2;       // Стек Ring 2 (не используется)
    uint32_t ss2;        // Сегмент Ring 2
    uint32_t cr3;        // Page directory
    uint32_t eip;        // Instruction pointer
    uint32_t eflags;     // Флаги
    uint32_t eax;        // Регистры общего назначения
    uint32_t ecx;
    uint32_t edx;
    uint32_t ebx;
    uint32_t esp;        // Stack pointer
    uint32_t ebp;        // Base pointer
    uint32_t esi;
    uint32_t edi;
    uint32_t es;         // Сегментные регистры
    uint32_t cs;
    uint32_t ss;
    uint32_t ds;
    uint32_t fs;
    uint32_t gs;
    uint32_t ldt;        // Local Descriptor Table (не используется)
    uint16_t trap;       // Trap flag
    uint16_t iomap_base; // I/O map base address
} __attribute__((packed)) tss_t;

// Инициализация TSS
void tss_init(void);

// Установить kernel stack для текущего процесса
void tss_set_kernel_stack(uint32_t stack);

// Получить текущий TSS
tss_t* tss_get(void);

#endif // TSS_H
