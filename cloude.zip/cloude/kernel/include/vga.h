#ifndef VGA_H
#define VGA_H

#include <stdint.h>

// VGA Register Ports
#define VGA_AC_INDEX         0x3C0
#define VGA_AC_WRITE         0x3C0
#define VGA_AC_READ          0x3C1
#define VGA_MISC_WRITE       0x3C2
#define VGA_SEQ_INDEX        0x3C4
#define VGA_SEQ_DATA         0x3C5
#define VGA_DAC_READ_INDEX   0x3C7
#define VGA_DAC_WRITE_INDEX  0x3C8
#define VGA_DAC_DATA         0x3C9
#define VGA_MISC_READ        0x3CC
#define VGA_GC_INDEX         0x3CE
#define VGA_GC_DATA          0x3CF
#define VGA_CRTC_INDEX       0x3D4
#define VGA_CRTC_DATA        0x3D5
#define VGA_INSTAT_READ      0x3DA

// VGA Memory
#define VGA_MEMORY           0xA0000

// VGA Modes
typedef enum {
    VGA_MODE_TEXT_80x25,
    VGA_MODE_GRAPHICS_320x200,
    VGA_MODE_GRAPHICS_640x480
} vga_mode_t;

// VGA Colors (standard 16-color palette)
#define VGA_COLOR_BLACK         0x00
#define VGA_COLOR_BLUE          0x01
#define VGA_COLOR_GREEN         0x02
#define VGA_COLOR_CYAN          0x03
#define VGA_COLOR_RED           0x04
#define VGA_COLOR_MAGENTA       0x05
#define VGA_COLOR_BROWN         0x06
#define VGA_COLOR_LIGHT_GRAY    0x07
#define VGA_COLOR_DARK_GRAY     0x08
#define VGA_COLOR_LIGHT_BLUE    0x09
#define VGA_COLOR_LIGHT_GREEN   0x0A
#define VGA_COLOR_LIGHT_CYAN    0x0B
#define VGA_COLOR_LIGHT_RED     0x0C
#define VGA_COLOR_LIGHT_MAGENTA 0x0D
#define VGA_COLOR_YELLOW        0x0E
#define VGA_COLOR_WHITE         0x0F

// Screen dimensions
#define VGA_WIDTH_320   320
#define VGA_HEIGHT_200  200
#define VGA_WIDTH_640   640
#define VGA_HEIGHT_480  480

// Functions
void vga_init(void);
void vga_set_mode(vga_mode_t mode);
void vga_plot_pixel(int x, int y, uint8_t color);
uint8_t vga_get_pixel(int x, int y);
void vga_draw_line(int x1, int y1, int x2, int y2, uint8_t color);
void vga_draw_rect(int x, int y, int w, int h, uint8_t color);
void vga_fill_rect(int x, int y, int w, int h, uint8_t color);
void vga_draw_circle(int cx, int cy, int radius, uint8_t color);
void vga_clear_screen(uint8_t color);
void vga_set_palette(uint8_t index, uint8_t r, uint8_t g, uint8_t b);

#endif // VGA_H
