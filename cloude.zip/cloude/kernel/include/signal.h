#ifndef SIGNAL_H
#define SIGNAL_H

#include <stdint.h>
#include "process.h"

// Standard Signals
#define SIGHUP      1   // Hangup
#define SIGINT      2   // Interrupt
#define SIGQUIT     3   // Quit
#define SIGILL      4   // Illegal instruction
#define SIGTRAP     5   // Trace/breakpoint trap
#define SIGABRT     6   // Abort
#define SIGBUS      7   // Bus error
#define SIGFPE      8   // Floating point exception
#define SIGKILL     9   // Kill (cannot be caught)
#define SIGUSR1     10  // User-defined signal 1
#define SIGSEGV     11  // Segmentation fault
#define SIGUSR2     12  // User-defined signal 2
#define SIGPIPE     13  // Broken pipe
#define SIGALRM     14  // Alarm clock
#define SIGTERM     15  // Termination
#define SIGCHLD     17  // Child stopped or terminated
#define SIGCONT     18  // Continue if stopped
#define SIGSTOP     19  // Stop process (cannot be caught)

#define MAX_SIGNALS 32

// Signal Handler
typedef void (*signal_handler_t)(int signum);

// Signal Info
typedef struct {
    uint32_t pending;
    uint32_t blocked;
    signal_handler_t handlers[MAX_SIGNALS];
} signal_info_t;

// Signal Functions
void signal_init(process_t* proc);
int signal_send(uint32_t pid, int signum);
int signal_set_handler(process_t* proc, int signum, signal_handler_t handler);
void signal_handle_pending(process_t* proc);
int signal_block(process_t* proc, int signum);
int signal_unblock(process_t* proc, int signum);

#endif // SIGNAL_H
