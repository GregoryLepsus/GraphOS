#ifndef WINDOW_H
#define WINDOW_H

#include <stdint.h>
#include "framebuffer.h"

// Window structure
typedef struct window {
    uint32_t id;
    char title[64];
    int x, y;
    int width, height;
    int z_order;
    int focused;
    int visible;
    int dragging;
    uint32_t bg_color;
    framebuffer_t* fb;
    struct window* next;
    struct window* prev;
} window_t;

// Window decorations
#define WINDOW_TITLE_HEIGHT 20
#define WINDOW_BORDER_WIDTH 2

// Window colors
#define WINDOW_COLOR_TITLE_ACTIVE   0x01  // Blue
#define WINDOW_COLOR_TITLE_INACTIVE 0x08  // Gray
#define WINDOW_COLOR_BORDER         0x0F  // White
#define WINDOW_COLOR_BACKGROUND     0x00  // Black

// Functions
void window_manager_init(void);
window_t* window_create(const char* title, int x, int y, int w, int h);
void window_destroy(window_t* win);
void window_move(window_t* win, int x, int y);
void window_resize(window_t* win, int w, int h);
void window_set_title(window_t* win, const char* title);
void window_focus(window_t* win);
void window_raise(window_t* win);
void window_draw(window_t* win);
void window_draw_all(void);
window_t* window_at_position(int x, int y);
void window_handle_mouse_event(int x, int y, uint8_t buttons);

#endif // WINDOW_H
