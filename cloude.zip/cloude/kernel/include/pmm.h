#ifndef PMM_H
#define PMM_H

#include "types.h"

// Physical Memory Manager (PMM)
// Управление физической памятью через bitmap allocator

// Размер страницы памяти
#define PAGE_SIZE 4096

// Информация о физической памяти
typedef struct {
    uint32_t total_memory;      // Всего памяти (KB)
    uint32_t used_memory;       // Использовано (KB)
    uint32_t free_memory;       // Свободно (KB)
    uint32_t total_pages;       // Всего страниц
    uint32_t used_pages;        // Использовано страниц
    uint8_t* bitmap;            // Bitmap для отслеживания страниц
    uint32_t bitmap_size;       // Размер bitmap в байтах
} pmm_info_t;

// Функции управления памятью
void pmm_init(uint32_t mem_size_kb);
void* pmm_alloc_page(void);
void pmm_free_page(void* page);
void* pmm_alloc_pages(uint32_t count);
void pmm_free_pages(void* pages, uint32_t count);
void pmm_get_info(pmm_info_t* info);
void pmm_mark_used(uint32_t page_index);
void pmm_mark_free(uint32_t page_index);

#endif // PMM_H
