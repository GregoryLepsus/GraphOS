#ifndef SHELL_H
#define SHELL_H

// Maximum limits
#define MAX_ARGS 32
#define MAX_PIPELINE 8
#define MAX_INPUT_LEN 256

// Command structure
typedef struct {
    char* args[MAX_ARGS];    // Аргументы команды
    int argc;                // Количество аргументов
    char* input_file;        // < input
    char* output_file;       // > output
    int append;              // >> append mode
    int background;          // & background
} command_t;

// Pipeline structure
typedef struct {
    command_t commands[MAX_PIPELINE];
    int count;               // Количество команд в pipeline
} pipeline_t;

// Parser functions
int parse_command(const char* line, command_t* cmd);
int parse_pipeline(const char* line, pipeline_t* pipeline);

// Executor functions
int execute_command(command_t* cmd);
int execute_pipeline(pipeline_t* pipeline);

// Built-in commands
int builtin_cd(int argc, char** argv);
int builtin_pwd(int argc, char** argv);
int builtin_export(int argc, char** argv);
int builtin_env(int argc, char** argv);

#endif // SHELL_H
