#ifndef SOCKET_H
#define SOCKET_H

#include <stdint.h>

// Address families
#define AF_INET 2

// Socket types
#define SOCK_STREAM 1  // TCP
#define SOCK_DGRAM  2  // UDP

// Protocol families
#define IPPROTO_TCP 6
#define IPPROTO_UDP 17

// Socket options
#define SO_REUSEADDR 1

// Maximum number of sockets
#define MAX_SOCKETS 32

// Socket states
typedef enum {
    SOCKET_STATE_CLOSED,
    SOCKET_STATE_BOUND,
    SOCKET_STATE_LISTENING,
    SOCKET_STATE_CONNECTED
} socket_state_t;

// Socket structure
typedef struct {
    int fd;
    int family;
    int type;
    int protocol;
    socket_state_t state;

    uint32_t local_ip;
    uint16_t local_port;
    uint32_t remote_ip;
    uint16_t remote_port;

    void* protocol_data;  // TCP or UDP socket data
    int valid;
} socket_t;

// Socket address structure
typedef struct {
    uint16_t family;
    uint16_t port;
    uint32_t addr;
    uint8_t zero[8];
} sockaddr_in_t;

// Functions
void socket_init(void);
int socket_create(int family, int type, int protocol);
int socket_bind(int sockfd, uint32_t addr, uint16_t port);
int socket_listen(int sockfd, int backlog);
int socket_accept(int sockfd);
int socket_connect(int sockfd, uint32_t addr, uint16_t port);
int socket_send(int sockfd, const void* buf, uint32_t len, int flags);
int socket_recv(int sockfd, void* buf, uint32_t len, int flags);
int socket_sendto(int sockfd, const void* buf, uint32_t len, uint32_t dest_addr, uint16_t dest_port);
int socket_recvfrom(int sockfd, void* buf, uint32_t len, uint32_t* src_addr, uint16_t* src_port);
int socket_close(int sockfd);

#endif // SOCKET_H
