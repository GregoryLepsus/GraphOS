#ifndef SYSCALL_H
#define SYSCALL_H

#include "types.h"

// System call numbers
#define SYS_EXIT        0
#define SYS_FORK        1
#define SYS_READ        2
#define SYS_WRITE       3
#define SYS_OPEN        4
#define SYS_CLOSE       5
#define SYS_WAITPID     6
#define SYS_CREAT       7
#define SYS_LINK        8
#define SYS_UNLINK      9
#define SYS_EXEC        10
#define SYS_CHDIR       11
#define SYS_TIME        12
#define SYS_GETPID      13
#define SYS_SLEEP       14
#define SYS_SBRK        15
#define SYS_YIELD       16

// Maximum number of syscalls
#define SYSCALL_MAX     17

// System call handler type
typedef uint32_t (*syscall_handler_t)(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);

// System call functions
void syscall_init(void);
void syscall_handler(uint32_t syscall_num, uint32_t arg1, uint32_t arg2,
                     uint32_t arg3, uint32_t arg4, uint32_t arg5);

// Individual syscall implementations
uint32_t sys_exit(uint32_t exit_code);
uint32_t sys_fork(void);
uint32_t sys_read(uint32_t fd, uint32_t buf, uint32_t count);
uint32_t sys_write(uint32_t fd, uint32_t buf, uint32_t count);
uint32_t sys_open(uint32_t pathname, uint32_t flags, uint32_t mode);
uint32_t sys_close(uint32_t fd);
uint32_t sys_getpid(void);
uint32_t sys_sleep(uint32_t seconds);
uint32_t sys_yield(void);

#endif // SYSCALL_H
