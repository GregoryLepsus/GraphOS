#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdint.h>
#include "process.h"
#include "thread.h"

// Scheduling Policies
#define SCHED_FIFO       0  // First-In-First-Out
#define SCHED_RR         1  // Round-Robin
#define SCHED_NORMAL     2  // Normal priority-based
#define SCHED_BATCH      3  // Batch processing
#define SCHED_IDLE       4  // Idle priority

// Priority Levels
#define PRIO_MIN         0
#define PRIO_MAX         7
#define PRIO_DEFAULT     4

// CPU Load Info
typedef struct {
    uint32_t cpu_id;
    uint32_t load_average;
    uint32_t tasks_running;
    uint32_t idle_time;
} cpu_load_t;

// Scheduler Statistics
typedef struct {
    uint64_t total_switches;
    uint64_t total_migrations;
    uint32_t current_tasks;
    uint32_t load_avg_1min;
    uint32_t load_avg_5min;
} sched_stats_t;

// Scheduling Functions
void scheduler_init_advanced(void);
void scheduler_set_policy(thread_t* thread, uint8_t policy);
void scheduler_set_priority(thread_t* thread, uint8_t priority);
void scheduler_balance_load(void);
cpu_load_t* scheduler_get_cpu_load(uint8_t cpu_id);
void scheduler_get_stats(sched_stats_t* stats);

#endif // SCHEDULER_H
