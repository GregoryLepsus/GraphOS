#ifndef ISR_H
#define ISR_H

#include "types.h"

// Структура регистров, сохраняемых при прерывании
struct registers {
    uint32_t ds;                                      // Data segment selector
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;  // Pushed by pusha
    uint32_t int_no, err_code;                        // Interrupt number and error code
    uint32_t eip, cs, eflags, useresp, ss;            // Pushed by the processor automatically
};

// Тип обработчика прерывания
typedef void (*isr_t)(struct registers*);

// Функции для работы с ISR
void init_isr(void);
void register_interrupt_handler(uint8_t n, isr_t handler);

// Внешние обработчики прерываний (определены в isr.asm)
extern void isr0(void);   // Division By Zero
extern void isr1(void);   // Debug
extern void isr2(void);   // Non Maskable Interrupt
extern void isr3(void);   // Breakpoint
extern void isr4(void);   // Into Detected Overflow
extern void isr5(void);   // Out of Bounds
extern void isr6(void);   // Invalid Opcode
extern void isr7(void);   // No Coprocessor
extern void isr8(void);   // Double Fault
extern void isr9(void);   // Coprocessor Segment Overrun
extern void isr10(void);  // Bad TSS
extern void isr11(void);  // Segment Not Present
extern void isr12(void);  // Stack Fault
extern void isr13(void);  // General Protection Fault
extern void isr14(void);  // Page Fault
extern void isr15(void);  // Unknown Interrupt
extern void isr16(void);  // Coprocessor Fault
extern void isr17(void);  // Alignment Check
extern void isr18(void);  // Machine Check
extern void isr19(void);  // Reserved
extern void isr20(void);  // Reserved
extern void isr21(void);  // Reserved
extern void isr22(void);  // Reserved
extern void isr23(void);  // Reserved
extern void isr24(void);  // Reserved
extern void isr25(void);  // Reserved
extern void isr26(void);  // Reserved
extern void isr27(void);  // Reserved
extern void isr28(void);  // Reserved
extern void isr29(void);  // Reserved
extern void isr30(void);  // Reserved
extern void isr31(void);  // Reserved

// IRQ handlers (будут добавлены после настройки PIC)
extern void irq0(void);   // Timer
extern void irq1(void);   // Keyboard
extern void irq2(void);   // Cascade
extern void irq3(void);   // COM2
extern void irq4(void);   // COM1
extern void irq5(void);   // LPT2
extern void irq6(void);   // Floppy
extern void irq7(void);   // LPT1
extern void irq8(void);   // RTC
extern void irq9(void);   // Free
extern void irq10(void);  // Free
extern void irq11(void);  // Free
extern void irq12(void);  // PS2 Mouse
extern void irq13(void);  // FPU
extern void irq14(void);  // Primary ATA
extern void irq15(void);  // Secondary ATA

#endif // ISR_H
