#ifndef ICMP_H
#define ICMP_H

#include <stdint.h>

// ICMP types
#define ICMP_TYPE_ECHO_REPLY   0
#define ICMP_TYPE_ECHO_REQUEST 8

// ICMP codes
#define ICMP_CODE_ECHO 0

// ICMP header
typedef struct {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint16_t identifier;
    uint16_t sequence;
} __attribute__((packed)) icmp_header_t;

// Functions
void icmp_init(void);
void icmp_receive(uint32_t src_ip, uint8_t* packet, uint32_t len);
int icmp_send_echo_request(uint32_t dest_ip, uint16_t id, uint16_t seq);

#endif // ICMP_H
