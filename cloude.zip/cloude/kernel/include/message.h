#ifndef MESSAGE_H
#define MESSAGE_H

#include <stdint.h>
#include "sync.h"

// Message Types
#define MSG_TYPE_DATA      1
#define MSG_TYPE_SIGNAL    2
#define MSG_TYPE_REQUEST   3
#define MSG_TYPE_RESPONSE  4

// Message Structure
typedef struct {
    uint32_t sender_pid;
    uint32_t sender_tid;
    uint32_t type;
    uint32_t size;
    uint8_t data[256];
} message_t;

// Message Queue
typedef struct message_node {
    message_t msg;
    struct message_node* next;
} message_node_t;

typedef struct {
    uint32_t id;
    uint32_t max_messages;
    uint32_t count;
    message_node_t* head;
    message_node_t* tail;
    mutex_t lock;
    semaphore_t not_empty;
    semaphore_t not_full;
} msgqueue_t;

// Message Queue Functions
msgqueue_t* msgqueue_create(uint32_t max_messages);
void msgqueue_destroy(msgqueue_t* queue);
int msg_send(msgqueue_t* queue, message_t* msg, uint32_t timeout);
int msg_receive(msgqueue_t* queue, message_t* msg, uint32_t timeout);
int msg_try_receive(msgqueue_t* queue, message_t* msg);
uint32_t msgqueue_count(msgqueue_t* queue);

#endif // MESSAGE_H
