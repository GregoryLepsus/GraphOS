#ifndef PAGING_H
#define PAGING_H

#include "types.h"

// Paging constants
#define PAGE_SIZE 4096
#define ENTRIES_PER_TABLE 1024
#define ENTRIES_PER_DIRECTORY 1024

// Page flags
#define PAGE_PRESENT   0x1    // Page is present in memory
#define PAGE_RW        0x2    // Read/Write (0 = read-only, 1 = read-write)
#define PAGE_USER      0x4    // User/Supervisor (0 = kernel, 1 = user)
#define PAGE_ACCESSED  0x20   // Page has been accessed
#define PAGE_DIRTY     0x40   // Page has been written to

// Page Table Entry (PTE)
typedef struct {
    uint32_t present    : 1;   // Page present in memory
    uint32_t rw         : 1;   // Read/write permission
    uint32_t user       : 1;   // User/supervisor mode
    uint32_t pwt        : 1;   // Page write-through
    uint32_t pcd        : 1;   // Page cache disabled
    uint32_t accessed   : 1;   // Has been accessed
    uint32_t dirty      : 1;   // Has been written to
    uint32_t pat        : 1;   // Page attribute table
    uint32_t global     : 1;   // Global page
    uint32_t available  : 3;   // Available for system use
    uint32_t frame      : 20;  // Frame address (4KB aligned)
} __attribute__((packed)) page_table_entry_t;

// Page Table
typedef struct {
    page_table_entry_t entries[ENTRIES_PER_TABLE];
} __attribute__((aligned(4096))) page_table_t;

// Page Directory Entry (PDE)
typedef struct {
    uint32_t present    : 1;
    uint32_t rw         : 1;
    uint32_t user       : 1;
    uint32_t pwt        : 1;
    uint32_t pcd        : 1;
    uint32_t accessed   : 1;
    uint32_t reserved   : 1;
    uint32_t page_size  : 1;   // 0 = 4KB pages, 1 = 4MB pages
    uint32_t ignored    : 1;
    uint32_t available  : 3;
    uint32_t table      : 20;  // Page table address (4KB aligned)
} __attribute__((packed)) page_directory_entry_t;

// Page Directory
typedef struct {
    page_directory_entry_t entries[ENTRIES_PER_DIRECTORY];
} __attribute__((aligned(4096))) page_directory_t;

// Current page directory
extern page_directory_t* current_directory;
extern page_directory_t* kernel_directory;

// Paging functions
void paging_init(void);
void paging_enable(void);
void paging_map_page(uint32_t virt, uint32_t phys, uint32_t flags);
void paging_unmap_page(uint32_t virt);
uint32_t paging_get_physical(uint32_t virt);
void paging_switch_directory(page_directory_t* dir);
void paging_flush_tlb(uint32_t virt);
page_directory_t* paging_clone_directory(page_directory_t* src);

#endif // PAGING_H
