#ifndef PROCESS_H
#define PROCESS_H

#include "types.h"
#include "paging.h"

// Process states
typedef enum {
    PROCESS_READY,      // Ready to run
    PROCESS_RUNNING,    // Currently running
    PROCESS_BLOCKED,    // Blocked (waiting for I/O, sleep, etc)
    PROCESS_DEAD        // Terminated
} process_state_t;

// CPU context saved during context switch
typedef struct {
    uint32_t eax, ebx, ecx, edx;
    uint32_t esi, edi, ebp, esp;
    uint32_t eip;
    uint32_t eflags;
    uint32_t cr3;  // Page directory
} cpu_context_t;

// Process Control Block (PCB)
typedef struct process {
    uint32_t pid;                       // Process ID
    char name[32];                      // Process name
    process_state_t state;              // Current state
    uint32_t priority;                  // Priority (0-7, lower = higher priority)

    cpu_context_t context;              // Saved CPU context

    uint32_t kernel_stack;              // Kernel stack pointer
    uint32_t user_stack;                // User stack pointer

    page_directory_t* page_directory;   // Virtual memory space

    uint32_t sleep_until;               // Wake up time (for sleep)

    struct process* next;               // Next process in queue
    struct process* prev;               // Previous process in queue
} process_t;

// Process management functions
void process_init(void);
process_t* process_create(const char* name, void (*entry_point)(void), uint32_t priority);
void process_exit(int exit_code);
void process_kill(uint32_t pid);
process_t* process_get_current(void);
process_t* process_get_by_pid(uint32_t pid);
void process_sleep(uint32_t ticks);
void process_wake(process_t* proc);
void process_list(void);

// Scheduler functions
void scheduler_init(void);
void schedule(void);
void scheduler_add_process(process_t* proc);
void scheduler_remove_process(process_t* proc);

// Context switching (implemented in assembly)
extern void switch_context(cpu_context_t* old_ctx, cpu_context_t* new_ctx);

// Global current process
extern process_t* current_process;
extern uint32_t next_pid;

#endif // PROCESS_H
