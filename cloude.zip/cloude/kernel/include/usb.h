#ifndef USB_H
#define USB_H

#include <stdint.h>

// USB Device Descriptor
typedef struct {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint16_t bcdUSB;
    uint8_t bDeviceClass;
    uint8_t bDeviceSubClass;
    uint8_t bDeviceProtocol;
    uint8_t bMaxPacketSize;
    uint16_t idVendor;
    uint16_t idProduct;
    uint16_t bcdDevice;
    uint8_t iManufacturer;
    uint8_t iProduct;
    uint8_t iSerialNumber;
    uint8_t bNumConfigurations;
} __attribute__((packed)) usb_device_descriptor_t;

// USB Device Structure
typedef struct usb_device {
    uint8_t address;
    uint8_t port;
    uint8_t speed;
    usb_device_descriptor_t descriptor;
    struct usb_device* next;
} usb_device_t;

// USB Request Types
#define USB_REQ_GET_STATUS        0x00
#define USB_REQ_CLEAR_FEATURE     0x01
#define USB_REQ_SET_FEATURE       0x03
#define USB_REQ_SET_ADDRESS       0x05
#define USB_REQ_GET_DESCRIPTOR    0x06
#define USB_REQ_SET_DESCRIPTOR    0x07
#define USB_REQ_GET_CONFIGURATION 0x08
#define USB_REQ_SET_CONFIGURATION 0x09

// USB Descriptor Types
#define USB_DESC_DEVICE           0x01
#define USB_DESC_CONFIGURATION    0x02
#define USB_DESC_STRING           0x03
#define USB_DESC_INTERFACE        0x04
#define USB_DESC_ENDPOINT         0x05

// USB Device Classes
#define USB_CLASS_HID             0x03
#define USB_CLASS_MASS_STORAGE    0x08
#define USB_CLASS_HUB             0x09

// USB Speed
#define USB_SPEED_LOW             0
#define USB_SPEED_FULL            1
#define USB_SPEED_HIGH            2

// Functions
void usb_init(void);
int usb_enumerate_devices(void);
usb_device_t* usb_get_device(uint8_t address);
int usb_control_transfer(usb_device_t* dev, uint8_t request_type,
                         uint8_t request, uint16_t value, uint16_t index,
                         void* data, uint16_t length);
int usb_bulk_transfer(usb_device_t* dev, uint8_t endpoint,
                      void* data, uint16_t length, int direction);

#endif // USB_H
