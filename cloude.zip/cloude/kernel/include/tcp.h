#ifndef TCP_H
#define TCP_H

#include <stdint.h>

// TCP header
typedef struct {
    uint16_t src_port;
    uint16_t dest_port;
    uint32_t seq_num;
    uint32_t ack_num;
    uint16_t flags;          // Data offset (4 bits) + Reserved (3 bits) + Flags (9 bits)
    uint16_t window;
    uint16_t checksum;
    uint16_t urgent_ptr;
} __attribute__((packed)) tcp_header_t;

// TCP flags
#define TCP_FLAG_FIN  0x001
#define TCP_FLAG_SYN  0x002
#define TCP_FLAG_RST  0x004
#define TCP_FLAG_PSH  0x008
#define TCP_FLAG_ACK  0x010
#define TCP_FLAG_URG  0x020

// TCP states
typedef enum {
    TCP_CLOSED,
    TCP_LISTEN,
    TCP_SYN_SENT,
    TCP_SYN_RECEIVED,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT_1,
    TCP_FIN_WAIT_2,
    TCP_CLOSE_WAIT,
    TCP_CLOSING,
    TCP_LAST_ACK,
    TCP_TIME_WAIT
} tcp_state_t;

// TCP socket structure
typedef struct {
    uint32_t local_ip;
    uint16_t local_port;
    uint32_t remote_ip;
    uint16_t remote_port;
    tcp_state_t state;
    uint32_t seq_num;
    uint32_t ack_num;
    uint16_t window;
} tcp_socket_t;

// Functions
void tcp_init(void);
int tcp_connect(tcp_socket_t* sock, uint32_t dest_ip, uint16_t dest_port);
int tcp_send(tcp_socket_t* sock, uint8_t* data, uint32_t len);
int tcp_receive(tcp_socket_t* sock, uint8_t* buf, uint32_t max_len);
void tcp_close(tcp_socket_t* sock);
void tcp_receive_packet(uint32_t src_ip, uint8_t* packet, uint32_t len);

#endif // TCP_H
