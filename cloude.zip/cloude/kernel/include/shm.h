#ifndef SHM_H
#define SHM_H

#include <stdint.h>

// Shared Memory Permissions
#define SHM_READ   0x01
#define SHM_WRITE  0x02
#define SHM_EXEC   0x04

// Shared Memory Region
typedef struct shm_region {
    uint32_t id;
    uint32_t size;
    void* kernel_addr;
    uint32_t ref_count;
    uint32_t permissions;
    uint32_t owner_pid;
    struct shm_region* next;
} shm_region_t;

// Shared Memory Attachment
typedef struct shm_attachment {
    uint32_t shm_id;
    uint32_t pid;
    void* address;
    struct shm_attachment* next;
} shm_attachment_t;

// Shared Memory Functions
shm_region_t* shm_create(uint32_t size, uint32_t permissions);
void* shm_attach(uint32_t shm_id, uint32_t pid);
int shm_detach(void* address, uint32_t pid);
int shm_destroy(uint32_t shm_id);
shm_region_t* shm_find(uint32_t shm_id);

#endif // SHM_H
