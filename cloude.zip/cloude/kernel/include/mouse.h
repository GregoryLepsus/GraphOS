#ifndef MOUSE_H
#define MOUSE_H

#include <stdint.h>

// Mouse state structure
typedef struct {
    int x, y;              // Current position
    int dx, dy;            // Delta movement
    uint8_t buttons;       // Button state (bit 0 = left, bit 1 = right, bit 2 = middle)
    int visible;           // Cursor visibility
} mouse_state_t;

// Mouse buttons
#define MOUSE_LEFT_BUTTON   0x01
#define MOUSE_RIGHT_BUTTON  0x02
#define MOUSE_MIDDLE_BUTTON 0x04

// Functions
void mouse_init(void);
void mouse_handler(void);
void mouse_get_position(int* x, int* y);
uint8_t mouse_get_buttons(void);
void mouse_show(void);
void mouse_hide(void);
void mouse_draw_cursor(void);

#endif // MOUSE_H
