#ifndef INITRD_H
#define INITRD_H

#include "types.h"
#include "vfs.h"

// InitRD header
typedef struct {
    uint32_t magic;         // Magic number
    uint32_t file_count;    // Number of files
} initrd_header_t;

// InitRD file header
typedef struct {
    char name[64];          // File name
    uint32_t offset;        // Offset in initrd
    uint32_t length;        // File size
} initrd_file_header_t;

// InitRD functions
vfs_node_t* initrd_init(uint32_t location);

#endif // INITRD_H
