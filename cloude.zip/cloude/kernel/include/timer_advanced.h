#ifndef TIMER_ADVANCED_H
#define TIMER_ADVANCED_H

#include <stdint.h>

// Timer Flags
#define TIMER_ONESHOT   0x00
#define TIMER_PERIODIC  0x01

// Timer Callback
typedef void (*timer_callback_t)(void* data);

// Timer Entry
typedef struct timer_entry {
    uint32_t id;
    timer_callback_t callback;
    void* data;
    uint32_t interval_ms;
    uint32_t expires_at;
    uint8_t flags;
    struct timer_entry* next;
} timer_entry_t;

// Timer Functions
void timer_advanced_init(void);
uint32_t timer_create(timer_callback_t callback, void* data, uint32_t interval_ms, uint8_t flags);
int timer_delete(uint32_t timer_id);
void timer_tick(void);
void nanosleep(uint32_t nanoseconds);

#endif // TIMER_ADVANCED_H
