#ifndef PROFILER_H
#define PROFILER_H

#include <stdint.h>

// Profiler Statistics
typedef struct {
    uint64_t total_syscalls;
    uint64_t total_interrupts;
    uint64_t total_context_switches;
    uint64_t memory_allocated;
    uint64_t memory_freed;
    uint32_t cpu_usage;
    uint32_t uptime_ms;
} profiler_stats_t;

// Profile Entry
typedef struct {
    char name[32];
    uint64_t start_time;
    uint64_t end_time;
    uint64_t duration;
} profile_entry_t;

// Profiler Functions
void profiler_init(void);
void profiler_record_syscall(uint32_t syscall_num);
void profiler_record_interrupt(uint32_t irq);
void profiler_record_context_switch(void);
void profiler_record_alloc(uint32_t size);
void profiler_record_free(uint32_t size);
void profiler_start(const char* name);
void profiler_end(const char* name);
void profiler_get_stats(profiler_stats_t* stats);
void profiler_update_cpu_usage(uint32_t usage_percent);
void profiler_update_uptime(uint32_t uptime_ms);

#endif // PROFILER_H
