#ifndef FONT_H
#define FONT_H

#include <stdint.h>

// Font structure
typedef struct {
    uint8_t width;
    uint8_t height;
    const uint8_t* glyphs;
    uint32_t glyph_count;
} font_t;

// Default 8x16 font
extern font_t font_8x16;

// Functions
void font_init(void);
void font_draw_char(font_t* font, char c, int x, int y, uint32_t fg, uint32_t bg);
void font_draw_string(font_t* font, const char* str, int x, int y, uint32_t fg, uint32_t bg);
int font_measure_string(font_t* font, const char* str);

#endif // FONT_H
