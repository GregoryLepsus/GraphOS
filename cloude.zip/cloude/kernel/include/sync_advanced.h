#ifndef SYNC_ADVANCED_H
#define SYNC_ADVANCED_H

#include <stdint.h>
#include "sync.h"
#include "thread.h"

// Recursive Mutex
typedef struct {
    spinlock_t lock;
    uint32_t owner_tid;
    uint32_t recursion_count;
} recursive_mutex_t;

// Reader-Writer Lock
typedef struct {
    spinlock_t lock;
    uint32_t readers;
    uint32_t writers;
    uint32_t write_waiting;
    semaphore_t read_sem;
    semaphore_t write_sem;
} rwlock_t;

// Condition Variable
typedef struct {
    spinlock_t lock;
    thread_t* waiting_threads;
} condvar_t;

// Barrier
typedef struct {
    uint32_t threshold;
    uint32_t count;
    uint32_t generation;
    mutex_t lock;
    condvar_t cv;
} barrier_t;

// Recursive Mutex Functions
void recursive_mutex_init(recursive_mutex_t* mutex);
void recursive_mutex_lock(recursive_mutex_t* mutex);
int recursive_mutex_trylock(recursive_mutex_t* mutex);
void recursive_mutex_unlock(recursive_mutex_t* mutex);

// Reader-Writer Lock Functions
void rwlock_init(rwlock_t* lock);
void rwlock_read_lock(rwlock_t* lock);
void rwlock_write_lock(rwlock_t* lock);
void rwlock_read_unlock(rwlock_t* lock);
void rwlock_write_unlock(rwlock_t* lock);

// Condition Variable Functions
void condvar_init(condvar_t* cv);
void condvar_wait(condvar_t* cv, mutex_t* mutex);
void condvar_signal(condvar_t* cv);
void condvar_broadcast(condvar_t* cv);

// Barrier Functions
void barrier_init(barrier_t* barrier, uint32_t threshold);
void barrier_wait(barrier_t* barrier);

#endif // SYNC_ADVANCED_H
