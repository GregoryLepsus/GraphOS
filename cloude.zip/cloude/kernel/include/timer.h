#ifndef TIMER_H
#define TIMER_H

#include "types.h"

// PIT (Programmable Interval Timer) порты
#define PIT_CHANNEL0 0x40
#define PIT_CHANNEL1 0x41
#define PIT_CHANNEL2 0x42
#define PIT_COMMAND  0x43

// PIT частота (Hz)
#define PIT_FREQUENCY 1193182

// Функции для работы с таймером
void init_timer(uint32_t frequency);
uint32_t timer_ticks(void);
void timer_wait(uint32_t ticks);

#endif // TIMER_H
