#ifndef HAL_H
#define HAL_H

#include <stdint.h>

// Device types
typedef enum {
    HAL_DEVICE_UNKNOWN,
    HAL_DEVICE_STORAGE,
    HAL_DEVICE_NETWORK,
    HAL_DEVICE_AUDIO,
    HAL_DEVICE_VIDEO,
    HAL_DEVICE_INPUT,
    HAL_DEVICE_USB,
    HAL_DEVICE_PCI
} hal_device_type_t;

// Device structure
typedef struct hal_device {
    uint32_t device_id;
    uint32_t vendor_id;
    hal_device_type_t type;
    char name[64];
    uint32_t flags;

    // Operations
    int (*init)(struct hal_device* dev);
    int (*shutdown)(struct hal_device* dev);
    int (*read)(struct hal_device* dev, void* buf, size_t size, uint64_t offset);
    int (*write)(struct hal_device* dev, const void* buf, size_t size, uint64_t offset);
    int (*ioctl)(struct hal_device* dev, uint32_t cmd, void* arg);

    void* private_data;
    struct hal_device* next;
} hal_device_t;

// Device flags
#define HAL_FLAG_INITIALIZED  0x01
#define HAL_FLAG_READY        0x02
#define HAL_FLAG_ERROR        0x04
#define HAL_FLAG_REMOVABLE    0x08

// Functions
void hal_init(void);
int hal_register_device(hal_device_t* device);
int hal_unregister_device(hal_device_t* device);
hal_device_t* hal_find_device(uint32_t vendor_id, uint32_t device_id);
hal_device_t* hal_find_device_by_type(hal_device_type_t type);
int hal_device_count(void);
hal_device_t* hal_get_device(int index);

#endif // HAL_H
