#ifndef UDP_H
#define UDP_H

#include <stdint.h>

// UDP header
typedef struct {
    uint16_t src_port;
    uint16_t dest_port;
    uint16_t length;
    uint16_t checksum;
} __attribute__((packed)) udp_header_t;

// UDP socket structure
typedef struct {
    uint16_t local_port;
    uint32_t remote_ip;
    uint16_t remote_port;
    int bound;
} udp_socket_t;

// Functions
void udp_init(void);
int udp_bind(udp_socket_t* sock, uint16_t port);
int udp_send(udp_socket_t* sock, uint32_t dest_ip, uint16_t dest_port, uint8_t* data, uint32_t len);
int udp_receive(udp_socket_t* sock, uint8_t* buf, uint32_t max_len, uint32_t* src_ip, uint16_t* src_port);
void udp_receive_packet(uint32_t src_ip, uint8_t* packet, uint32_t len);

#endif // UDP_H
