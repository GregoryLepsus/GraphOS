#ifndef NETUTILS_H
#define NETUTILS_H

#include <stdint.h>

// Network byte order conversion
uint16_t htons(uint16_t hostshort);
uint16_t ntohs(uint16_t netshort);
uint32_t htonl(uint32_t hostlong);
uint32_t ntohl(uint32_t netlong);

// IP address utilities
uint32_t ip_from_string(const char* str);
void ip_to_string(uint32_t ip, char* buf);
int ip_is_valid(const char* str);

// MAC address utilities
void mac_to_string(const uint8_t* mac, char* buf);
int mac_from_string(const char* str, uint8_t* mac);

// Checksum utilities
uint16_t checksum(const uint8_t* data, uint32_t len);
uint16_t tcp_udp_checksum(uint32_t src_ip, uint32_t dest_ip, uint8_t protocol, const uint8_t* data, uint32_t len);

#endif // NETUTILS_H
