#ifndef VFS_H
#define VFS_H

#include "types.h"

// File types
#define VFS_FILE        1
#define VFS_DIRECTORY   2
#define VFS_CHARDEVICE  3
#define VFS_BLOCKDEVICE 4
#define VFS_PIPE        5
#define VFS_SYMLINK     6

// File flags
#define O_RDONLY    0x0001
#define O_WRONLY    0x0002
#define O_RDWR      0x0003
#define O_CREAT     0x0100
#define O_TRUNC     0x0200
#define O_APPEND    0x0400

// Seek modes
#define SEEK_SET    0
#define SEEK_CUR    1
#define SEEK_END    2

// Forward declarations
typedef struct vfs_node vfs_node_t;
typedef struct dirent dirent_t;

// Directory entry
struct dirent {
    char name[128];
    uint32_t inode;
};

// VFS node operations
typedef uint32_t (*read_type_t)(vfs_node_t*, uint32_t, uint32_t, uint8_t*);
typedef uint32_t (*write_type_t)(vfs_node_t*, uint32_t, uint32_t, uint8_t*);
typedef void (*open_type_t)(vfs_node_t*);
typedef void (*close_type_t)(vfs_node_t*);
typedef dirent_t* (*readdir_type_t)(vfs_node_t*, uint32_t);
typedef vfs_node_t* (*finddir_type_t)(vfs_node_t*, const char* name);

// VFS node structure
struct vfs_node {
    char name[128];         // File name
    uint32_t mask;          // Permissions mask
    uint32_t uid;           // User ID
    uint32_t gid;           // Group ID
    uint32_t flags;         // Node type (file, dir, etc)
    uint32_t inode;         // Inode number
    uint32_t length;        // File size
    uint32_t impl;          // Implementation-specific field

    // Operations
    read_type_t read;
    write_type_t write;
    open_type_t open;
    close_type_t close;
    readdir_type_t readdir;
    finddir_type_t finddir;

    vfs_node_t* ptr;        // Used for symlinks, mountpoints
};

// VFS functions
void vfs_init(void);
uint32_t vfs_read(vfs_node_t* node, uint32_t offset, uint32_t size, uint8_t* buffer);
uint32_t vfs_write(vfs_node_t* node, uint32_t offset, uint32_t size, uint8_t* buffer);
void vfs_open(vfs_node_t* node, uint32_t flags);
void vfs_close(vfs_node_t* node);
dirent_t* vfs_readdir(vfs_node_t* node, uint32_t index);
vfs_node_t* vfs_finddir(vfs_node_t* node, const char* name);

// Root filesystem
extern vfs_node_t* vfs_root;

#endif // VFS_H
