#ifndef SECURITY_H
#define SECURITY_H

#include <stdint.h>

// User & Group IDs
#define UID_ROOT    0
#define GID_ROOT    0

// Permissions
#define PERM_READ   0x4
#define PERM_WRITE  0x2
#define PERM_EXEC   0x1

// User Info
typedef struct {
    uint32_t uid;
    uint32_t gid;
    char username[32];
    uint32_t capabilities;
} user_t;

// File Permissions
typedef struct {
    uint32_t owner_uid;
    uint32_t owner_gid;
    uint8_t owner_perms;
    uint8_t group_perms;
    uint8_t other_perms;
} file_perms_t;

// Security Functions
void security_init(void);
int security_check_permission(user_t* user, file_perms_t* perms, uint8_t access);
user_t* security_get_user(uint32_t uid);
int security_create_user(const char* username, uint32_t uid, uint32_t gid);

#endif // SECURITY_H
