#ifndef SMP_H
#define SMP_H

#include <stdint.h>

// CPU States
#define CPU_STATE_OFFLINE   0
#define CPU_STATE_ONLINE    1
#define CPU_STATE_RUNNING   2

// CPU Info Structure
typedef struct {
    uint8_t cpu_id;
    uint8_t apic_id;
    uint8_t state;
    uint32_t flags;
    void* stack;
    void* tss;
} cpu_info_t;

// SMP Functions
void smp_init(void);
int smp_get_cpu_count(void);
cpu_info_t* smp_get_current_cpu(void);
cpu_info_t* smp_get_cpu(uint8_t cpu_id);
void smp_start_ap(uint8_t apic_id);
void smp_send_ipi(uint8_t cpu_id, uint8_t vector);
void smp_broadcast_ipi(uint8_t vector);

#endif // SMP_H
