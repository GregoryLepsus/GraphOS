#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include <stdint.h>

// Framebuffer structure
typedef struct {
    uint32_t width;
    uint32_t height;
    uint8_t bpp;           // Bits per pixel
    uint32_t pitch;        // Bytes per scanline
    uint8_t* buffer;       // Front buffer (VGA memory)
    uint8_t* backbuffer;   // Back buffer (for double buffering)
    int double_buffer_enabled;
} framebuffer_t;

// Global framebuffer
extern framebuffer_t* fb;

// Functions
void fb_init(uint32_t width, uint32_t height, uint8_t bpp);
void fb_clear(uint32_t color);
void fb_put_pixel(int x, int y, uint32_t color);
uint32_t fb_get_pixel(int x, int y);
void fb_draw_line(int x1, int y1, int x2, int y2, uint32_t color);
void fb_draw_rect(int x, int y, int w, int h, uint32_t color);
void fb_fill_rect(int x, int y, int w, int h, uint32_t color);
void fb_draw_circle(int cx, int cy, int radius, uint32_t color);
void fb_fill_circle(int cx, int cy, int radius, uint32_t color);
void fb_swap_buffers(void);
void fb_enable_double_buffer(int enable);

#endif // FRAMEBUFFER_H
