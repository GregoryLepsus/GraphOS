#ifndef HEAP_H
#define HEAP_H

#include "types.h"

// Heap block header
typedef struct heap_block {
    uint32_t size;              // Size of block (including header)
    bool allocated;             // Is block allocated?
    struct heap_block* next;    // Next block in list
    struct heap_block* prev;    // Previous block in list
} heap_block_t;

// Heap structure
typedef struct {
    uint32_t start_address;     // Start of heap
    uint32_t end_address;       // Current end of heap
    uint32_t max_address;       // Maximum heap size
    heap_block_t* first_block;  // First block in list
    uint32_t total_allocated;   // Total allocated bytes
    uint32_t total_free;        // Total free bytes
    uint32_t num_blocks;        // Number of blocks
} heap_t;

// Heap management functions
void heap_init(uint32_t start, uint32_t size);
void* kmalloc(uint32_t size);
void kfree(void* ptr);
void* krealloc(void* ptr, uint32_t size);
void heap_get_stats(uint32_t* total_allocated, uint32_t* total_free, uint32_t* num_blocks);

// Alignment
#define HEAP_ALIGN 16
#define HEAP_ALIGN_MASK (HEAP_ALIGN - 1)
#define HEAP_ALIGN_UP(x) (((x) + HEAP_ALIGN_MASK) & ~HEAP_ALIGN_MASK)

// Minimum block size
#define HEAP_MIN_BLOCK_SIZE 32

#endif // HEAP_H
