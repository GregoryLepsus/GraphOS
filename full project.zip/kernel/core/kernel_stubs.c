#include <stdint.h>
#include <stddef.h>

extern void terminal_putchar(char c);

void terminal_write_hex(uint32_t val) {
    char hex_chars[] = "0123456789ABCDEF";
    terminal_putchar('0');
    terminal_putchar('x');
    for (int i = 28; i >= 0; i -= 4) {
        terminal_putchar(hex_chars[(val >> i) & 0xF]);
    }
}

uint32_t timer_get_ticks(void) {
    static uint32_t ticks = 0;
    return ++ticks;
}

void* process_get(int pid) {
    (void)pid;
    return NULL;
}
