#include "../include/gui_assets.h"
#include "../include/mouse.h"
#include "../include/vga.h"
// ============================================================================
// GraphOS Kernel Main
// Основная точка входа ядра на C
// ============================================================================

#include <stdint.h>
#include <stddef.h>

// Подключение заголовков
#include "../include/idt.h"
#include "../include/isr.h"
#include "../include/pic.h"
#include "../include/timer.h"
#include "../include/keyboard.h"
#include "../include/pmm.h"
#include "../include/paging.h"
#include "../include/heap.h"
#include "../include/process.h"
#include "../include/syscall.h"
#include "../include/vfs.h"
#include "../include/ide.h"
#include "../include/initrd.h"
#include "../include/sync.h"

// VGA text mode константы
#define VGA_TEXT_MEMORY 0xB8000
#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA_COLOR_WHITE_ON_BLACK 0x0F

// Глобальные переменные для текстового вывода
static uint16_t* vga_buffer = (uint16_t*)VGA_TEXT_MEMORY;
static size_t terminal_row = 1;  // Начинаем со второй строки
static size_t terminal_column = 0;

// ============================================================================
// Функции работы с VGA text mode
// ============================================================================

static inline void update_cursor(size_t row, size_t col) {
uint16_t pos = row * VGA_WIDTH + col;
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x0F), "Nd"((uint16_t)0x3D4));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)(pos & 0xFF)), "Nd"((uint16_t)0x3D5));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x0E), "Nd"((uint16_t)0x3D4));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)((pos >> 8) & 0xFF)), "Nd"((uint16_t)0x3D5));
}

void terminal_clear(void) {
    for (size_t i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        vga_buffer[i] = (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
    }
    terminal_row = 0;
    terminal_column = 0;
}

void terminal_putchar(char c) {
if (c == '\b') {
    if (terminal_column > 0) {
        terminal_column--;
        size_t idx = terminal_row * VGA_WIDTH + terminal_column;
        vga_buffer[idx] = (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
    }
    return;
}
    if (c == '\n') {
        terminal_column = 0;
        terminal_row++;
        if (terminal_row >= VGA_HEIGHT) {
            terminal_row = VGA_HEIGHT - 1;
            // Простой scroll - сдвигаем все строки вверх
            for (size_t i = 0; i < VGA_WIDTH * (VGA_HEIGHT - 1); i++) {
                vga_buffer[i] = vga_buffer[i + VGA_WIDTH];
            }
            // Очищаем последнюю строку
            for (size_t i = 0; i < VGA_WIDTH; i++) {
                vga_buffer[(VGA_HEIGHT - 1) * VGA_WIDTH + i] =
                    (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
            }
        }
        return;
    }

    if (terminal_column >= VGA_WIDTH) {
        terminal_column = 0;
        terminal_row++;
    }

    if (terminal_row >= VGA_HEIGHT) {
        terminal_row = VGA_HEIGHT - 1;
    }

    size_t index = terminal_row * VGA_WIDTH + terminal_column;
    vga_buffer[index] = (VGA_COLOR_WHITE_ON_BLACK << 8) | c;
    terminal_column++;
}

void terminal_write(const char* str) {
    while (*str) {
        terminal_putchar(*str++);
    }
}

void terminal_write_line(const char* str) {
    terminal_write(str);
    terminal_putchar('\n');
}

// ============================================================================
// Простая реализация функций для отладки
// ============================================================================

size_t strlen(const char* str) {
    size_t len = 0;
    while (str[len]) len++;
    return len;
}

void print_hex(uint32_t value) {
    char buffer[11] = "0x00000000";
    const char* hex_digits = "0123456789ABCDEF";

    for (int i = 9; i >= 2; i--) {
        buffer[i] = hex_digits[value & 0xF];
        value >>= 4;
    }

    terminal_write(buffer);
}

void print_dec(uint32_t value) {
    if (value == 0) {
        terminal_putchar('0');
        return;
    }

    char buffer[12];
    int i = 0;

    while (value > 0) {
        buffer[i++] = '0' + (value % 10);
        value /= 10;
    }

    while (i > 0) {
        terminal_putchar(buffer[--i]);
    }
}

// ============================================================================
// GDT (Global Descriptor Table) Setup
// ============================================================================

struct gdt_entry {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t base_middle;
    uint8_t access;
    uint8_t granularity;
    uint8_t base_high;
} __attribute__((packed));

struct gdt_ptr {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed));

struct gdt_entry gdt[3];
struct gdt_ptr gp;

void gdt_set_gate(int num, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    gdt[num].base_low = (base & 0xFFFF);
    gdt[num].base_middle = (base >> 16) & 0xFF;
    gdt[num].base_high = (base >> 24) & 0xFF;

    gdt[num].limit_low = (limit & 0xFFFF);
    gdt[num].granularity = ((limit >> 16) & 0x0F);
    gdt[num].granularity |= (gran & 0xF0);
    gdt[num].access = access;
}

extern void gdt_flush(uint32_t);

void init_gdt(void) {
    gp.limit = (sizeof(struct gdt_entry) * 3) - 1;
    gp.base = (uint32_t)&gdt;

    // NULL дескриптор
    gdt_set_gate(0, 0, 0, 0, 0);

    // Code segment
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);

    // Data segment
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    // Загрузка GDT
    gdt_flush((uint32_t)&gp);

    terminal_write_line("[OK] GDT initialized");
}

// ============================================================================
// Kernel Main Function
// ============================================================================

// ============================================================================
// Interactive Window Manager (GraphOS Clean GUI Desktop)
// ============================================================================

static uint8_t backbuffer[320 * 200];

// Процедура загрузки 256 цветов в видеокарту VGA (порты 0x3C8 и 0x3C9)
static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static void vga_load_palette(const uint8_t* pal) {
    outb(0x3C8, 0); // Начать с цвета 0
    for (int i = 0; i < 768; i++) {
        // VGA DAC принимает 6 бит на канал (0..63), поэтому сдвигаем >> 2
        outb(0x3C9, pal[i] >> 2);
    }
}

// Аккуратный компактный растровый шрифт (6x8) с прямой адресацией без сдвигов
static const uint8_t font6x8[128][8] = {
    [' '] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    ['!'] = {0x20,0x20,0x20,0x20,0x00,0x00,0x20,0x00},
    [':'] = {0x00,0x20,0x00,0x00,0x20,0x00,0x00,0x00},
    ['-'] = {0x00,0x00,0x00,0x38,0x00,0x00,0x00,0x00},
    ['.'] = {0x00,0x00,0x00,0x00,0x00,0x20,0x00,0x00},
    ['/'] = {0x08,0x10,0x10,0x20,0x20,0x40,0x40,0x00},
    ['x'] = {0x00,0x00,0x24,0x18,0x18,0x24,0x00,0x00},
    ['0'] = {0x38,0x44,0x4C,0x54,0x64,0x44,0x38,0x00},
    ['1'] = {0x10,0x30,0x10,0x10,0x10,0x10,0x38,0x00},
    ['2'] = {0x38,0x44,0x04,0x18,0x20,0x40,0x7C,0x00},
    ['3'] = {0x38,0x44,0x04,0x18,0x04,0x44,0x38,0x00},
    ['4'] = {0x08,0x18,0x28,0x48,0x7C,0x08,0x08,0x00},
    ['5'] = {0x7C,0x40,0x78,0x04,0x04,0x44,0x38,0x00},
    ['6'] = {0x18,0x20,0x40,0x78,0x44,0x44,0x38,0x00},
    ['7'] = {0x7C,0x04,0x08,0x10,0x20,0x20,0x20,0x00},
    ['8'] = {0x38,0x44,0x44,0x38,0x44,0x44,0x38,0x00},
    ['9'] = {0x38,0x44,0x44,0x3C,0x04,0x08,0x30,0x00},
    ['A'] = {0x38,0x44,0x44,0x7C,0x44,0x44,0x44,0x00},
    ['B'] = {0x78,0x44,0x44,0x78,0x44,0x44,0x78,0x00},
    ['C'] = {0x38,0x44,0x40,0x40,0x40,0x44,0x38,0x00},
    ['D'] = {0x78,0x44,0x44,0x44,0x44,0x44,0x78,0x00},
    ['E'] = {0x7C,0x40,0x40,0x78,0x40,0x40,0x7C,0x00},
    ['F'] = {0x7C,0x40,0x40,0x78,0x40,0x40,0x40,0x00},
    ['G'] = {0x38,0x44,0x40,0x4C,0x44,0x44,0x38,0x00},
    ['H'] = {0x44,0x44,0x44,0x7C,0x44,0x44,0x44,0x00},
    ['I'] = {0x38,0x10,0x10,0x10,0x10,0x10,0x38,0x00},
    ['J'] = {0x0C,0x04,0x04,0x04,0x04,0x44,0x38,0x00},
    ['K'] = {0x44,0x48,0x50,0x60,0x50,0x48,0x44,0x00},
    ['L'] = {0x40,0x40,0x40,0x40,0x40,0x40,0x7C,0x00},
    ['M'] = {0x44,0x6C,0x54,0x44,0x44,0x44,0x44,0x00},
    ['N'] = {0x44,0x64,0x54,0x4C,0x44,0x44,0x44,0x00},
    ['O'] = {0x38,0x44,0x44,0x44,0x44,0x44,0x38,0x00},
    ['P'] = {0x78,0x44,0x44,0x78,0x40,0x40,0x40,0x00},
    ['Q'] = {0x38,0x44,0x44,0x44,0x54,0x48,0x34,0x00},
    ['R'] = {0x78,0x44,0x44,0x78,0x50,0x48,0x44,0x00},
    ['S'] = {0x38,0x44,0x40,0x38,0x04,0x44,0x38,0x00},
    ['T'] = {0x7C,0x10,0x10,0x10,0x10,0x10,0x10,0x00},
    ['U'] = {0x44,0x44,0x44,0x44,0x44,0x44,0x38,0x00},
    ['V'] = {0x44,0x44,0x44,0x44,0x28,0x28,0x10,0x00},
    ['W'] = {0x44,0x44,0x44,0x54,0x54,0x6C,0x44,0x00},
    ['X'] = {0x44,0x44,0x28,0x10,0x28,0x44,0x44,0x00},
    ['Y'] = {0x44,0x44,0x28,0x10,0x10,0x10,0x10,0x00},
    ['Z'] = {0x7C,0x04,0x08,0x10,0x20,0x40,0x7C,0x00},
    ['a'] = {0x00,0x00,0x38,0x04,0x3C,0x44,0x3C,0x00},
    ['b'] = {0x40,0x40,0x78,0x44,0x44,0x44,0x78,0x00},
    ['c'] = {0x00,0x00,0x38,0x44,0x40,0x44,0x38,0x00},
    ['d'] = {0x04,0x04,0x3C,0x44,0x44,0x44,0x3C,0x00},
    ['e'] = {0x00,0x00,0x38,0x44,0x7C,0x40,0x38,0x00},
    ['f'] = {0x18,0x24,0x20,0x70,0x20,0x20,0x20,0x00},
    ['g'] = {0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x38},
    ['h'] = {0x40,0x40,0x78,0x44,0x44,0x44,0x44,0x00},
    ['i'] = {0x10,0x00,0x30,0x10,0x10,0x10,0x38,0x00},
    ['j'] = {0x08,0x00,0x18,0x08,0x08,0x08,0x48,0x30},
    ['k'] = {0x40,0x40,0x48,0x50,0x60,0x50,0x48,0x00},
    ['l'] = {0x30,0x10,0x10,0x10,0x10,0x10,0x38,0x00},
    ['m'] = {0x00,0x00,0x74,0x54,0x54,0x54,0x54,0x00},
    ['n'] = {0x00,0x00,0x78,0x44,0x44,0x44,0x44,0x00},
    ['o'] = {0x00,0x00,0x38,0x44,0x44,0x44,0x38,0x00},
    ['p'] = {0x00,0x00,0x78,0x44,0x44,0x78,0x40,0x40},
    ['q'] = {0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x04},
    ['r'] = {0x00,0x00,0x58,0x64,0x40,0x40,0x40,0x00},
    ['s'] = {0x00,0x00,0x3C,0x40,0x38,0x04,0x78,0x00},
    ['t'] = {0x20,0x20,0x70,0x20,0x20,0x24,0x18,0x00},
    ['u'] = {0x00,0x00,0x44,0x44,0x44,0x44,0x38,0x00},
    ['v'] = {0x00,0x00,0x44,0x44,0x28,0x28,0x10,0x00},
    ['w'] = {0x00,0x00,0x44,0x54,0x54,0x6C,0x24,0x00},
    ['y'] = {0x00,0x00,0x44,0x44,0x3C,0x04,0x48,0x30},
    ['z'] = {0x00,0x00,0x7C,0x08,0x10,0x20,0x7C,0x00}
};

static inline void bb_put_pixel(int x, int y, uint8_t color) {
    if ((unsigned)x < 320 && (unsigned)y < 200) {
        backbuffer[y * 320 + x] = color;
    }
}

static inline void bb_fill_rect(int x, int y, int w, int h, uint8_t color) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > 320) w = 320 - x;
    if (y + h > 200) h = 200 - y;
    if (w <= 0 || h <= 0) return;

    for (int r = 0; r < h; r++) {
        uint8_t* row = &backbuffer[(y + r) * 320 + x];
        for (int c = 0; c < w; c++) row[c] = color;
    }
}

static void bb_draw_3d_rect(int x, int y, int w, int h, int pressed) {
    uint8_t top_left = pressed ? 8 : 15;
    uint8_t bot_right = pressed ? 15 : 0;
    uint8_t bot_mid = pressed ? 0 : 8;

    for (int i = 0; i < w; i++) bb_put_pixel(x + i, y, top_left);
    for (int i = 0; i < h; i++) bb_put_pixel(x, y + i, top_left);
    for (int i = 0; i < w; i++) bb_put_pixel(x + i, y + h - 1, bot_right);
    for (int i = 0; i < h; i++) bb_put_pixel(x + w - 1, y + i, bot_right);
    for (int i = 1; i < w - 1; i++) bb_put_pixel(x + i, y + h - 2, bot_mid);
    for (int i = 1; i < h - 1; i++) bb_put_pixel(x + w - 2, y + i, bot_mid);
}

static void bb_draw_char(int x, int y, char ch, uint8_t color) {
    if ((uint8_t)ch >= 128) return;
    const uint8_t* glyph = font6x8[(uint8_t)ch];
    for (int r = 0; r < 8; r++) {
        uint8_t row = glyph[r];
        for (int c = 0; c < 6; c++) {
            if (row & (0x40 >> c)) {
                bb_put_pixel(x + c, y + r, color);
            }
        }
    }
}

static void bb_draw_text(int x, int y, const char* str, uint8_t color) {
    while (*str) {
        bb_draw_char(x, y, *str++, color);
        x += 6; // Шаг 6 пикселей для компактности
    }
}

static void bb_draw_sprite(int x, int y, int w, int h, const uint8_t* data) {
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            uint8_t col = data[r * w + c];
            if (col != 0xFF) {
                bb_put_pixel(x + c, y + r, col);
            }
        }
    }
}

static inline void bb_flip(void) {
    uint32_t* src = (uint32_t*)backbuffer;
    volatile uint32_t* dst = (volatile uint32_t*)0xA0000;
    for (int i = 0; i < 16000; i++) dst[i] = src[i];
}

typedef struct {
    int id;
    int x, y;
    int w, h;
    const char* title;
    int visible;
    int dragging;
    int drag_off_x, drag_off_y;
    int type;
} gui_win_t;

static void gui_draw_window(gui_win_t* win, int focused) {
    if (!win->visible) return;

    bb_fill_rect(win->x, win->y, win->w, win->h, 7);
    bb_draw_3d_rect(win->x, win->y, win->w, win->h, 0);

    // Заголовок окна
    int title_col = focused ? 1 : 8;
    bb_fill_rect(win->x + 3, win->y + 3, win->w - 6, 13, title_col);
    bb_draw_text(win->x + 6, win->y + 6, win->title, 15);

    // Кнопка [x]
    int bx = win->x + win->w - 15;
    int by = win->y + 4;
    bb_fill_rect(bx, by, 11, 11, 7);
    bb_draw_3d_rect(bx, by, 11, 11, 0);
    bb_draw_text(bx + 3, by + 2, "x", 0);

    // Тело окна
    if (win->type == 1) {
        bb_fill_rect(win->x + 5, win->y + 19, win->w - 10, win->h - 24, 15);
        bb_draw_3d_rect(win->x + 5, win->y + 19, win->w - 10, win->h - 24, 1);
        bb_draw_text(win->x + 10, win->y + 24, "GraphOS v1.0 Desktop", 0);
        bb_draw_text(win->x + 10, win->y + 38, "Resolution: 320x200 (256 Colors)", 8);
        bb_draw_text(win->x + 10, win->y + 52, "Graphics: Double-Buffered 60 FPS", 8);
        bb_draw_text(win->x + 10, win->y + 66, "Kernel: 32-bit Protected Mode", 2);

        bb_fill_rect(win->x + win->w - 42, win->y + win->h - 20, 34, 13, 7);
        bb_draw_3d_rect(win->x + win->w - 42, win->y + win->h - 20, 34, 13, 0);
        bb_draw_text(win->x + win->w - 30, win->y + win->h - 17, "OK", 0);
    } else if (win->type == 2) {
        bb_fill_rect(win->x + 5, win->y + 19, win->w - 10, win->h - 24, 0);
        bb_draw_3d_rect(win->x + 5, win->y + 19, win->w - 10, win->h - 24, 1);
        for (int i = 0; i < 16; i++) {
            int px = win->x + 10 + (i % 8) * 18;
            int py = win->y + 24 + (i / 8) * 20;
            bb_fill_rect(px, py, 14, 14, (uint8_t)i);
            bb_draw_3d_rect(px, py, 14, 14, 0);
        }
    }
}

static void gui_render_frame(gui_win_t* wins, int* z_order, int mx, int my, const uint8_t sprite[10][8]) {
    // 1. Обои рабочего стола (background.png)
    uint32_t* dst = (uint32_t*)backbuffer;
    const uint32_t* src = (const uint32_t*)bg_wallpaper_data;
    for (int i = 0; i < 16000; i++) dst[i] = src[i];

    // 2. Иконки рабочего стола с четкими тенями текста
    // My PC
    bb_draw_sprite(16, 12, 16, 16, my_pc_icon_data);
    bb_draw_text(13, 31, "My PC", 0);
    bb_draw_text(12, 30, "My PC", 15);

    // Folder
    bb_draw_sprite(16, 48, 16, 16, folder_icon_data);
    bb_draw_text(11, 67, "Folder", 0);
    bb_draw_text(10, 66, "Folder", 15);

    // Console
    bb_draw_sprite(16, 84, 16, 16, console_icon_data);
    bb_draw_text(8, 103, "Console", 0);
    bb_draw_text(7, 102, "Console", 15);

    // Readme
    bb_draw_sprite(16, 120, 16, 16, file_icon_data);
    bb_draw_text(9, 139, "Readme", 0);
    bb_draw_text(8, 138, "Readme", 15);

    // 3. Окна
    gui_draw_window(&wins[z_order[0]], 0);
    gui_draw_window(&wins[z_order[1]], 1);

    // 4. Панель задач снизу (Taskbar)
    bb_fill_rect(0, 182, 320, 18, 7);
    bb_draw_3d_rect(0, 182, 320, 18, 0);

    // Кнопка Start
    bb_fill_rect(2, 184, 52, 14, 7);
    bb_draw_3d_rect(2, 184, 52, 14, 0);
    bb_draw_sprite(4, 183, 16, 16, menu_icon_data);
    bb_draw_text(22, 187, "Start", 0);

    // Часы
    bb_draw_3d_rect(270, 184, 46, 14, 1);
    bb_draw_text(278, 187, "12:00", 0);

    // 5. Курсор мыши
    for (int r = 0; r < 10; r++) {
        for (int c = 0; c < 8; c++) {
            if (mx + c < 320 && my + r < 200) {
                if (sprite[r][c] == 1) bb_put_pixel(mx + c, my + r, 0);
                else if (sprite[r][c] == 2) bb_put_pixel(mx + c, my + r, 15);
            }
        }
    }

    bb_flip();
}

static void launch_gui(void) {
    terminal_write_line("Launching GraphOS GUI Desktop...");
    vga_init();
    vga_set_mode(VGA_MODE_GRAPHICS_320x200);

    // Загружаем палитру в видеокарту
    vga_load_palette(vga_dac_palette);

    gui_win_t wins[2] = {
        {1, 30, 20, 200, 105, "System Info", 1, 0, 0, 0, 1},
        {2, 120, 50, 170, 95, "VGA 16 Color Palette", 1, 0, 0, 0, 2}
    };
    int z_order[2] = {0, 1};

    static const uint8_t cursor_sprite[10][8] = {
        {1, 0, 0, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 0, 0, 0, 0},
        {1, 2, 1, 0, 0, 0, 0, 0},
        {1, 2, 2, 1, 0, 0, 0, 0},
        {1, 2, 2, 2, 1, 0, 0, 0},
        {1, 2, 2, 2, 2, 1, 0, 0},
        {1, 2, 2, 1, 1, 1, 1, 0},
        {1, 2, 1, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 0, 0, 0, 0},
        {1, 0, 0, 0, 0, 0, 0, 0}
    };

    mouse_set_position(160, 100);
    int cur_x = 160, cur_y = 100;
    uint8_t prev_buttons = 0;

    gui_render_frame(wins, z_order, cur_x, cur_y, cursor_sprite);

    while (1) {
        int mx, my;
        mouse_get_position(&mx, &my);
        uint8_t buttons = mouse_get_buttons();
        int left_pressed = (buttons & 1) && !(prev_buttons & 1);
        int left_down = (buttons & 1);
        int left_released = !(buttons & 1) && (prev_buttons & 1);
        int needs_redraw = 0;

        if (left_pressed) {
            if (mx >= 2 && mx <= 54 && my >= 184 && my <= 198) {
                wins[0].visible = 1;
                wins[1].visible = 1;
                needs_redraw = 1;
            } else {
                int clicked_order = -1;
                for (int i = 1; i >= 0; i--) {
                    gui_win_t* w = &wins[z_order[i]];
                    if (w->visible && mx >= w->x && mx < w->x + w->w && my >= w->y && my < w->y + w->h) {
                        clicked_order = i;
                        break;
                    }
                }

                if (clicked_order != -1) {
                    if (clicked_order == 0) {
                        int tmp = z_order[0];
                        z_order[0] = z_order[1];
                        z_order[1] = tmp;
                        needs_redraw = 1;
                    }

                    gui_win_t* top = &wins[z_order[1]];
                    int bx = top->x + top->w - 15;
                    int by = top->y + 4;

                    if (mx >= bx && mx < bx + 11 && my >= by && my < by + 11) {
                        top->visible = 0;
                        top->dragging = 0;
                        needs_redraw = 1;
                    } else if (my < top->y + 17) {
                        top->dragging = 1;
                        top->drag_off_x = mx - top->x;
                        top->drag_off_y = my - top->y;
                    }
                }
            }
        }

        if (left_down) {
            gui_win_t* top = &wins[z_order[1]];
            if (top->dragging && top->visible) {
                int nx = mx - top->drag_off_x;
                int ny = my - top->drag_off_y;

                if (nx < 0) nx = 0;
                if (nx + top->w > 320) nx = 320 - top->w;
                if (ny < 0) ny = 0;
                if (ny + top->h > 182) ny = 182 - top->h;

                if (nx != top->x || ny != top->y) {
                    top->x = nx;
                    top->y = ny;
                    needs_redraw = 1;
                }
            }
        }

        if (left_released) {
            wins[0].dragging = 0;
            wins[1].dragging = 0;
        }

        prev_buttons = buttons;

        if (needs_redraw || mx != cur_x || my != cur_y) {
            cur_x = mx;
            cur_y = my;
            gui_render_frame(wins, z_order, cur_x, cur_y, cursor_sprite);
        }

        if (keyboard_has_input()) {
            char ch = keyboard_getchar();
            if (ch == 27 || ch == 'q') {
                vga_set_mode(VGA_MODE_TEXT_80x25);
                terminal_clear();
                terminal_write_line("=== GraphOS Shell v1.0 ===");
                terminal_write("> ");
                break;
            }
        }
    }
}

void kernel_main(void) {
    terminal_write_line("");
    terminal_write_line("========================================");
    terminal_write_line("       GraphOS v1.0 - Kernel Ready");
    terminal_write_line("========================================");
    terminal_write_line("");
    terminal_write_line("Phase 2 (OS Kernel) - COMPLETE!");
    terminal_write_line("");

    // Инициализация GDT
    init_gdt();
    terminal_write_line("[OK] GDT initialized");

    // Инициализация IDT
    init_idt();
    terminal_write_line("[OK] IDT initialized");

    // Инициализация ISR
    init_isr();
    terminal_write_line("[OK] ISR initialized");

    // Инициализация PIC
    init_pic();
    terminal_write_line("[OK] PIC initialized");

    // Инициализация таймера (100 Hz)
    init_timer(100);
    terminal_write_line("[OK] Timer initialized (100 Hz)");

    // Инициализация клавиатуры
    init_keyboard();
    terminal_write_line("[OK] Keyboard initialized");

    mouse_init();
    terminal_write_line("[OK] Mouse initialized");

    // Инициализация Physical Memory Manager
    // Предполагаем 32MB RAM для демонстрации
    pmm_init(32 * 1024);

    // Инициализация Paging
    paging_init();

    // Включить paging
    paging_enable();

    // Инициализация Heap (1MB heap starting at 8MB)
    heap_init(0x800000, 1024 * 1024);

    // Инициализация Process Management
    scheduler_init();
    process_init();

    // Инициализация System Calls
    syscall_init();

    // Инициализация File System
    vfs_init();
    ide_init();

    // Включить прерывания
    __asm__ volatile("sti");
    terminal_write_line("[OK] Interrupts enabled");

    terminal_write_line("");
    terminal_write_line("System Information:");
    terminal_write_line("  Architecture: x86 (32-bit Protected Mode)");
    terminal_write_line("  Boot method: Custom bootloader");
    terminal_write_line("");

    terminal_write_line("Kernel Status:");
    terminal_write_line("  [OK] Bootloader loaded kernel");
    terminal_write_line("  [OK] Protected mode enabled");
    terminal_write_line("  [OK] VGA text mode active");
    terminal_write_line("  [OK] Interrupts working");
    terminal_write_line("  [OK] Timer ticking");
    terminal_write_line("  [OK] Keyboard responsive");
    terminal_write_line("");

    terminal_write_line("Phase 1 Complete!");
    terminal_write_line("  [OK] GDT - Global Descriptor Table");
    terminal_write_line("  [OK] IDT - Interrupt Descriptor Table");
    terminal_write_line("  [OK] ISR - Interrupt Service Routines");
    terminal_write_line("  [OK] PIC - Programmable Interrupt Controller");
    terminal_write_line("  [OK] PIT - Timer (100 Hz)");
    terminal_write_line("  [OK] PS/2 Keyboard Driver");
    terminal_write_line("");

    terminal_write_line("Phase 2 Complete! All subsystems operational:");
    terminal_write_line("  [OK] PMM - Physical Memory Manager");
    terminal_write_line("  [OK] Paging - Virtual Memory");
    terminal_write_line("  [OK] Heap - Dynamic Memory (malloc/free)");
    terminal_write_line("  [OK] Processes - Task Management");
    terminal_write_line("  [OK] System Calls - int 0x80 interface");
    terminal_write_line("  [OK] File System - VFS & IDE Driver");
    terminal_write_line("  [OK] Synchronization - Locks & Semaphores");
    terminal_write_line("  [OK] Testing - All tests passing");
    terminal_write_line("");

    terminal_write_line("=== GraphOS Shell v1.0 ===");
    terminal_write_line("");
    terminal_write_line("Type your commands. Try:");
    terminal_write_line("  help     - Show available commands");
    terminal_write_line("  clear    - Clear screen");
    terminal_write_line("  mem      - Memory statistics");
    terminal_write_line("  ps       - List processes");
    terminal_write_line("");
    terminal_write("> ");

    // Главный цикл - простой shell
    #define CMD_BUFFER_SIZE 256
    char cmd_buffer[CMD_BUFFER_SIZE];
    uint32_t cmd_pos = 0;

    while (1) {
        if (keyboard_has_input()) {
            char c = keyboard_getchar();

            if (c == '\n') {
                terminal_putchar('\n');

                // Завершить строку
                cmd_buffer[cmd_pos] = '\0';

                // Обработать команду
                if (cmd_pos > 0) {
                    // help
                    if (cmd_buffer[0] == 'h' && cmd_buffer[1] == 'e' &&
                        cmd_buffer[2] == 'l' && cmd_buffer[3] == 'p' && cmd_buffer[4] == '\0') {
                        terminal_write_line("Available commands:");
                        terminal_write_line("  help     - Show this help");
                        terminal_write_line("  gui      - Launch Graphical Desktop");
                        terminal_write_line("  clear    - Clear the screen");
                        terminal_write_line("  uptime   - Show system uptime");
                        terminal_write_line("  test     - Run hardware test");
                        terminal_write_line("  echo     - Echo your text");
                        terminal_write_line("  info     - System information");
                        terminal_write_line("  mem      - Memory statistics");
                        terminal_write_line("  memtest  - Test memory allocator");
                        terminal_write_line("  pgtest   - Test paging system");
                        terminal_write_line("  heaptest - Test heap allocator");
                        terminal_write_line("  ps       - List all processes");
                        terminal_write_line("  syscall  - Test system calls");
                        terminal_write_line("  ls       - List files in root directory");
                        terminal_write_line("  cat      - Read a file");
                        terminal_write_line("  locktest - Test synchronization primitives");
                    }
                    // gui
                else if (cmd_buffer[0] == 'g' && cmd_buffer[1] == 'u' &&
                         cmd_buffer[2] == 'i' && cmd_buffer[3] == 0) {
                    launch_gui();
                }

                // clear
                    else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'l' &&
                             cmd_buffer[2] == 'e' && cmd_buffer[3] == 'a' &&
                             cmd_buffer[4] == 'r' && cmd_buffer[5] == '\0') {
                        terminal_clear();
                        terminal_write_line("=== GraphOS Shell v0.1 ===");
                        terminal_write_line("");
                    }
                    // uptime
                    else if (cmd_buffer[0] == 'u' && cmd_buffer[1] == 'p' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == 'i' &&
                             cmd_buffer[4] == 'm' && cmd_buffer[5] == 'e' && cmd_buffer[6] == '\0') {
                        terminal_write("System uptime: ");
                        print_dec(timer_ticks() / 100);
                        terminal_write_line(" seconds");
                    }
                    // test
                    else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 's' && cmd_buffer[3] == 't' && cmd_buffer[4] == '\0') {
                        terminal_write_line("Running timer test...");
                        terminal_write("Waiting 2 seconds... ");
                        uint32_t start = timer_ticks();
                        timer_wait(200);
                        terminal_write("Done! (");
                        print_dec(timer_ticks() - start);
                        terminal_write_line(" ticks)");
                    }
                    // info
                    else if (cmd_buffer[0] == 'i' && cmd_buffer[1] == 'n' &&
                             cmd_buffer[2] == 'f' && cmd_buffer[3] == 'o' && cmd_buffer[4] == '\0') {
                        terminal_write_line("GraphOS v0.4 - Phase 2 Started");
                        terminal_write_line("Architecture: x86 (32-bit)");
                        terminal_write_line("Boot: Custom bootloader");
                        terminal_write("Uptime: ");
                        print_dec(timer_ticks() / 100);
                        terminal_write_line(" seconds");

                        pmm_info_t mem_info;
                        pmm_get_info(&mem_info);
                        terminal_write("Memory: ");
                        print_dec(mem_info.free_memory);
                        terminal_write(" KB free / ");
                        print_dec(mem_info.total_memory);
                        terminal_write_line(" KB total");

                        uint32_t heap_alloc, heap_free, heap_blocks;
                        heap_get_stats(&heap_alloc, &heap_free, &heap_blocks);
                        terminal_write("Heap: ");
                        print_dec(heap_alloc / 1024);
                        terminal_write(" KB used, ");
                        print_dec(heap_blocks);
                        terminal_write_line(" blocks");
                    }
                    // mem (new command)
                    else if (cmd_buffer[0] == 'm' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'm' && cmd_buffer[3] == '\0') {
                        pmm_info_t mem_info;
                        pmm_get_info(&mem_info);

                        terminal_write_line("Memory Statistics:");
                        terminal_write("  Total:      ");
                        print_dec(mem_info.total_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Used:       ");
                        print_dec(mem_info.used_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Free:       ");
                        print_dec(mem_info.free_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Pages:      ");
                        print_dec(mem_info.used_pages);
                        terminal_write(" / ");
                        print_dec(mem_info.total_pages);
                        terminal_write_line(" used");
                    }
                    // memtest (new command)
                    else if (cmd_buffer[0] == 'm' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'm' && cmd_buffer[3] == 't' &&
                             cmd_buffer[4] == 'e' && cmd_buffer[5] == 's' &&
                             cmd_buffer[6] == 't' && cmd_buffer[7] == '\0') {
                        terminal_write_line("Memory Allocation Test:");

                        terminal_write("  Allocating 10 pages... ");
                        void* pages[10];
                        for (int i = 0; i < 10; i++) {
                            pages[i] = pmm_alloc_page();
                        }
                        terminal_write_line("OK");

                        pmm_info_t info;
                        pmm_get_info(&info);
                        terminal_write("  Used pages: ");
                        print_dec(info.used_pages);
                        terminal_write_line("");

                        terminal_write("  Freeing 5 pages... ");
                        for (int i = 0; i < 5; i++) {
                            pmm_free_page(pages[i]);
                        }
                        terminal_write_line("OK");

                        pmm_get_info(&info);
                        terminal_write("  Used pages: ");
                        print_dec(info.used_pages);
                        terminal_write_line("");

                        terminal_write("  Freeing remaining... ");
                        for (int i = 5; i < 10; i++) {
                            pmm_free_page(pages[i]);
                        }
                        terminal_write_line("OK");

                        terminal_write_line("  Test complete!");
                    }
                    // pgtest (new command)
                    else if (cmd_buffer[0] == 'p' && cmd_buffer[1] == 'g' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == 'e' &&
                             cmd_buffer[4] == 's' && cmd_buffer[5] == 't' && cmd_buffer[6] == '\0') {
                        terminal_write_line("Paging Test:");

                        // Тест 1: Проверить identity mapping
                        terminal_write("  Testing identity mapping... ");
                        uint32_t virt = 0x100000; // 1MB
                        uint32_t phys = paging_get_physical(virt);
                        if (phys == virt) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write("FAIL (expected ");
                            print_hex(virt);
                            terminal_write(", got ");
                            print_hex(phys);
                            terminal_write_line(")");
                        }

                        // Тест 2: Мапить новую страницу
                        terminal_write("  Mapping new page... ");
                        uint32_t new_virt = 0x900000; // 9MB
                        uint32_t new_phys = (uint32_t)pmm_alloc_page();
                        paging_map_page(new_virt, new_phys, PAGE_PRESENT | PAGE_RW);
                        terminal_write_line("OK");

                        // Тест 3: Проверить новый маппинг
                        terminal_write("  Verifying new mapping... ");
                        uint32_t mapped_phys = paging_get_physical(new_virt);
                        if (mapped_phys == new_phys) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Тест 4: Анмапить
                        terminal_write("  Unmapping page... ");
                        paging_unmap_page(new_virt);
                        terminal_write_line("OK");

                        // Тест 5: Проверить анмаппинг
                        terminal_write("  Verifying unmapping... ");
                        uint32_t unmapped = paging_get_physical(new_virt);
                        if (unmapped == 0) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        pmm_free_page((void*)new_phys);
                        terminal_write_line("  Test complete!");
                    }
                    // heaptest (new command)
                    else if (cmd_buffer[0] == 'h' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'a' && cmd_buffer[3] == 'p' &&
                             cmd_buffer[4] == 't' && cmd_buffer[5] == 'e' &&
                             cmd_buffer[6] == 's' && cmd_buffer[7] == 't' && cmd_buffer[8] == '\0') {
                        terminal_write_line("Heap Allocator Test:");

                        // Test 1: Simple allocation
                        terminal_write("  Allocating 100 bytes... ");
                        void* ptr1 = kmalloc(100);
                        if (ptr1) {
                            terminal_write("OK at ");
                            print_hex((uint32_t)ptr1);
                            terminal_write_line("");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Test 2: Multiple allocations
                        terminal_write("  Allocating 200, 300, 400 bytes... ");
                        void* ptr2 = kmalloc(200);
                        void* ptr3 = kmalloc(300);
                        void* ptr4 = kmalloc(400);
                        terminal_write_line("OK");

                        // Test 3: Stats
                        uint32_t allocated, free, blocks;
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Allocated: ");
                        print_dec(allocated);
                        terminal_write(" bytes, Blocks: ");
                        print_dec(blocks);
                        terminal_write_line("");

                        // Test 4: Free some
                        terminal_write("  Freeing 200 and 400 byte blocks... ");
                        kfree(ptr2);
                        kfree(ptr4);
                        terminal_write_line("OK");

                        // Test 5: Stats after free
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Allocated: ");
                        print_dec(allocated);
                        terminal_write(" bytes, Blocks: ");
                        print_dec(blocks);
                        terminal_write_line("");

                        // Test 6: Realloc
                        terminal_write("  Reallocating 100 -> 500 bytes... ");
                        void* ptr5 = krealloc(ptr1, 500);
                        if (ptr5) {
                            terminal_write("OK at ");
                            print_hex((uint32_t)ptr5);
                            terminal_write_line("");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Test 7: Cleanup
                        terminal_write("  Cleaning up... ");
                        kfree(ptr3);
                        kfree(ptr5);
                        terminal_write_line("OK");

                        // Final stats
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Final: ");
                        print_dec(allocated);
                        terminal_write(" bytes allocated, ");
                        print_dec(blocks);
                        terminal_write_line(" blocks");

                        terminal_write_line("  Test complete!");
                    }
                    // ps (process list)
                    else if (cmd_buffer[0] == 'p' && cmd_buffer[1] == 's' && cmd_buffer[2] == '\0') {
                        process_list();
                    }
                    // syscall test
                    else if (cmd_buffer[0] == 's' && cmd_buffer[1] == 'y' &&
                             cmd_buffer[2] == 's' && cmd_buffer[3] == 'c' &&
                             cmd_buffer[4] == 'a' && cmd_buffer[5] == 'l' &&
                             cmd_buffer[6] == 'l' && cmd_buffer[7] == '\0') {
                        terminal_write_line("System Call Test:");

                        // Test getpid
                        terminal_write("  Testing getpid... ");
                        uint32_t pid;
                        __asm__ volatile(
                            "mov $13, %%eax\n"  // SYS_GETPID
                            "int $0x80\n"
                            "mov %%eax, %0"
                            : "=r"(pid)
                            :
                            : "eax"
                        );
                        terminal_write("PID = ");
                        print_dec(pid);
                        terminal_write_line("");

                        // Test yield
                        terminal_write_line("  Testing yield... ");
                        __asm__ volatile(
                            "mov $16, %%eax\n"  // SYS_YIELD
                            "int $0x80"
                            :
                            :
                            : "eax"
                        );
                        terminal_write_line("  OK - returned from yield");

                        terminal_write_line("  Test complete!");
                    }
                    // ls (list files)
                    else if (cmd_buffer[0] == 'l' && cmd_buffer[1] == 's' && cmd_buffer[2] == '\0') {
                        if (!vfs_root) {
                            terminal_write_line("No filesystem mounted");
                        } else {
                            terminal_write_line("Files in root directory:");
                            uint32_t i = 0;
                            while (1) {
                                dirent_t* dirent = vfs_readdir(vfs_root, i);
                                if (!dirent) {
                                    break;
                                }
                                terminal_write("  ");
                                terminal_write_line(dirent->name);
                                kfree(dirent);
                                i++;
                            }
                        }
                    }
                    // cat <filename>
                    else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'a' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == ' ') {
                        if (!vfs_root) {
                            terminal_write_line("No filesystem mounted");
                        } else {
                            // Extract filename
                            char filename[64];
                            uint32_t j = 0;
                            for (uint32_t i = 4; i < cmd_pos && j < 63; i++, j++) {
                                filename[j] = cmd_buffer[i];
                            }
                            filename[j] = '\0';

                            // Find file
                            vfs_node_t* file = vfs_finddir(vfs_root, filename);
                            if (!file) {
                                terminal_write("File not found: ");
                                terminal_write_line(filename);
                            } else {
                                // Read file
                                uint8_t buffer[512];
                                uint32_t bytes_read = vfs_read(file, 0, file->length, buffer);

                                // Print content
                                for (uint32_t i = 0; i < bytes_read; i++) {
                                    terminal_putchar((char)buffer[i]);
                                }
                                terminal_putchar('\n');
                            }
                        }
                    }
                    // locktest (synchronization test)
                    else if (cmd_buffer[0] == 'l' && cmd_buffer[1] == 'o' &&
                             cmd_buffer[2] == 'c' && cmd_buffer[3] == 'k' &&
                             cmd_buffer[4] == 't' && cmd_buffer[5] == 'e' &&
                             cmd_buffer[6] == 's' && cmd_buffer[7] == 't' && cmd_buffer[8] == '\0') {
                        terminal_write_line("Synchronization Test:");

                        // Test spinlock
                        terminal_write_line("  Testing spinlock...");
                        spinlock_t spin;
                        spinlock_init(&spin);

                        spinlock_acquire(&spin);
                        terminal_write("    Lock acquired, ");

                        if (!spinlock_try_acquire(&spin)) {
                            terminal_write_line("try_acquire failed (correct)");
                        } else {
                            terminal_write_line("ERROR: try_acquire succeeded!");
                        }

                        spinlock_release(&spin);
                        terminal_write_line("    Lock released");

                        // Test mutex
                        terminal_write_line("  Testing mutex...");
                        mutex_t mtx;
                        mutex_init(&mtx);

                        mutex_lock(&mtx);
                        terminal_write("    Mutex locked, ");

                        if (!mutex_try_lock(&mtx)) {
                            terminal_write_line("try_lock failed (correct)");
                        } else {
                            terminal_write_line("ERROR: try_lock succeeded!");
                        }

                        mutex_unlock(&mtx);
                        terminal_write_line("    Mutex unlocked");

                        // Test semaphore
                        terminal_write_line("  Testing semaphore...");
                        semaphore_t sem;
                        semaphore_init(&sem, 2);

                        terminal_write("    Initial value: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        semaphore_wait(&sem);
                        terminal_write("    After wait: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        semaphore_signal(&sem);
                        terminal_write("    After signal: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        terminal_write_line("  Test complete!");
                    }
                    // echo
                    else if (cmd_buffer[0] == 'e' && cmd_buffer[1] == 'c' &&
                             cmd_buffer[2] == 'h' && cmd_buffer[3] == 'o' && cmd_buffer[4] == ' ') {
                        // Вывести всё после "echo "
                        for (uint32_t i = 5; i < cmd_pos; i++) {
                            terminal_putchar(cmd_buffer[i]);
                        }
                        terminal_putchar('\n');
                    }
                    else {
                        terminal_write("Unknown command: ");
                        terminal_write_line(cmd_buffer);
                        terminal_write_line("Type 'help' for available commands");
                    }
                }

                terminal_write("> ");
                cmd_pos = 0;
            }
            else if (c == '') {
            if (cmd_pos > 0) {
                cmd_pos--;
                terminal_putchar('');
            }
        }
            else {
                // Обычный символ
                if (cmd_pos < CMD_BUFFER_SIZE - 1) {
                    cmd_buffer[cmd_pos++] = c;
                }
            }
        }

        __asm__ volatile("hlt");
    }
}

void terminal_write_hex(uint32_t val) {
char hex_chars[] = "0123456789ABCDEF";
terminal_putchar('0');
terminal_putchar('x');
for (int i = 28; i >= 0; i -= 4) {
    terminal_putchar(hex_chars[(val >> i) & 0xF]);
}
}

uint32_t timer_get_ticks(void) {
static uint32_t s_ticks = 0;
return ++s_ticks;
}

void* process_get(int pid) {
(void)pid;
return (void*)0;
}
