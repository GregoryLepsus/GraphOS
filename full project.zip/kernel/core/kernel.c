#include "../include/gui_assets.h"
#include "../include/mouse.h"
#include "../include/vga.h"
// ============================================================================
// GraphOS Kernel Main
// Основная точка входа ядра на C
// ============================================================================

#include <stdint.h>
static uint32_t gui_start_ticks = 0;
#include <stddef.h>

// Подключение заголовков
#include "../include/idt.h"
#include "../include/isr.h"
#include "../include/pic.h"
#include "../include/timer.h"
#include "../include/keyboard.h"
#include "../include/pmm.h"
#include "../include/paging.h"
#include "../include/heap.h"
#include "../include/process.h"
#include "../include/syscall.h"
#include "../include/vfs.h"
#include "../include/ide.h"
#include "../include/initrd.h"
#include "../include/sync.h"

// VGA text mode константы
#define VGA_TEXT_MEMORY 0xB8000
#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA_COLOR_WHITE_ON_BLACK 0x0F

// Глобальные переменные для текстового вывода
static uint16_t* vga_buffer = (uint16_t*)VGA_TEXT_MEMORY;
static size_t terminal_row = 1;  // Начинаем со второй строки
static size_t terminal_column = 0;

// ============================================================================
// Функции работы с VGA text mode
// ============================================================================

static inline void update_cursor(size_t row, size_t col) {
uint16_t pos = row * VGA_WIDTH + col;
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x0F), "Nd"((uint16_t)0x3D4));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)(pos & 0xFF)), "Nd"((uint16_t)0x3D5));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x0E), "Nd"((uint16_t)0x3D4));
__asm__ volatile("outb %0, %1" : : "a"((uint8_t)((pos >> 8) & 0xFF)), "Nd"((uint16_t)0x3D5));
}

void terminal_clear(void) {
    for (size_t i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        vga_buffer[i] = (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
    }
    terminal_row = 0;
    terminal_column = 0;
}

void terminal_putchar(char c) {
if (c == '\b') {
    if (terminal_column > 0) {
        terminal_column--;
        size_t idx = terminal_row * VGA_WIDTH + terminal_column;
        vga_buffer[idx] = (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
    }
    return;
}
    if (c == '\n') {
        terminal_column = 0;
        terminal_row++;
        if (terminal_row >= VGA_HEIGHT) {
            terminal_row = VGA_HEIGHT - 1;
            // Простой scroll - сдвигаем все строки вверх
            for (size_t i = 0; i < VGA_WIDTH * (VGA_HEIGHT - 1); i++) {
                vga_buffer[i] = vga_buffer[i + VGA_WIDTH];
            }
            // Очищаем последнюю строку
            for (size_t i = 0; i < VGA_WIDTH; i++) {
                vga_buffer[(VGA_HEIGHT - 1) * VGA_WIDTH + i] =
                    (VGA_COLOR_WHITE_ON_BLACK << 8) | ' ';
            }
        }
        return;
    }

    if (terminal_column >= VGA_WIDTH) {
        terminal_column = 0;
        terminal_row++;
    }

    if (terminal_row >= VGA_HEIGHT) {
        terminal_row = VGA_HEIGHT - 1;
    }

    size_t index = terminal_row * VGA_WIDTH + terminal_column;
    vga_buffer[index] = (VGA_COLOR_WHITE_ON_BLACK << 8) | c;
    terminal_column++;
}

void terminal_write(const char* str) {
    while (*str) {
        terminal_putchar(*str++);
    }
}

void terminal_write_line(const char* str) {
    terminal_write(str);
    terminal_putchar('\n');
}

// ============================================================================
// Простая реализация функций для отладки
// ============================================================================

size_t strlen(const char* str) {
    size_t len = 0;
    while (str[len]) len++;
    return len;
}

void print_hex(uint32_t value) {
    char buffer[11] = "0x00000000";
    const char* hex_digits = "0123456789ABCDEF";

    for (int i = 9; i >= 2; i--) {
        buffer[i] = hex_digits[value & 0xF];
        value >>= 4;
    }

    terminal_write(buffer);
}

void print_dec(uint32_t value) {
    if (value == 0) {
        terminal_putchar('0');
        return;
    }

    char buffer[12];
    int i = 0;

    while (value > 0) {
        buffer[i++] = '0' + (value % 10);
        value /= 10;
    }

    while (i > 0) {
        terminal_putchar(buffer[--i]);
    }
}

// ============================================================================
// GDT (Global Descriptor Table) Setup
// ============================================================================

struct gdt_entry {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t base_middle;
    uint8_t access;
    uint8_t granularity;
    uint8_t base_high;
} __attribute__((packed));

struct gdt_ptr {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed));

struct gdt_entry gdt[3];
struct gdt_ptr gp;

void gdt_set_gate(int num, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    gdt[num].base_low = (base & 0xFFFF);
    gdt[num].base_middle = (base >> 16) & 0xFF;
    gdt[num].base_high = (base >> 24) & 0xFF;

    gdt[num].limit_low = (limit & 0xFFFF);
    gdt[num].granularity = ((limit >> 16) & 0x0F);
    gdt[num].granularity |= (gran & 0xF0);
    gdt[num].access = access;
}

extern void gdt_flush(uint32_t);

void init_gdt(void) {
    gp.limit = (sizeof(struct gdt_entry) * 3) - 1;
    gp.base = (uint32_t)&gdt;

    // NULL дескриптор
    gdt_set_gate(0, 0, 0, 0, 0);

    // Code segment
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);

    // Data segment
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    // Загрузка GDT
    gdt_flush((uint32_t)&gp);

    terminal_write_line("[OK] GDT initialized");
}

// ============================================================================
// Kernel Main Function
// ============================================================================

// ============================================================================
// Interactive Window Manager (Win95 Desktop, Resize, RTC Clock & Shutdown)
// ============================================================================

static uint8_t backbuffer[320 * 200];

static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline void outw(uint16_t port, uint16_t val) {
    __asm__ volatile("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void vga_vsync_wait(void) {
    int timeout = 50000;
    while ((inb(0x3DA) & 8) && --timeout);
    timeout = 50000;
    while (!(inb(0x3DA) & 8) && --timeout);
}

static void vga_load_palette(const uint8_t* pal) {
    outb(0x3C8, 0);
    for (int i = 0; i < 768; i++) {
        outb(0x3C9, pal[i] >> 2);
    }
}

// ============================================================================
// CMOS Real-Time Clock
// ============================================================================
static uint8_t rtc_read(uint8_t reg) {
    outb(0x70, reg);
    return inb(0x71);
}

static int rtc_is_updating(void) {
    outb(0x70, 0x0A);
    return (inb(0x71) & 0x80);
}

static uint8_t bcd_to_bin(uint8_t val) {
    return ((val / 16) * 10) + (val % 16);
}

static void rtc_get_time(int* hours, int* minutes) {
    int timeout = 10000;
    while (rtc_is_updating() && --timeout);

    uint8_t min = rtc_read(0x02);
    uint8_t hr  = rtc_read(0x04);
    uint8_t regB = rtc_read(0x0B);

    if (!(regB & 0x04)) {
        min = bcd_to_bin(min);
        hr  = ((hr & 0x7F) / 16) * 10 + (hr & 0x0F);
    }

    if (!(regB & 0x02) && (rtc_read(0x04) & 0x80)) {
        hr = ((hr & 0x7F) + 12) % 24;
    }

    *hours = hr;
    *minutes = min;
}

extern volatile uint32_t mouse_irq_count;
extern volatile uint8_t mouse_ack_reset;
extern volatile uint8_t mouse_ack_stream;
static char cached_clock[6] = "00:00";
static uint32_t clock_tick = 0;

static void update_clock(void) {
    clock_tick++;
    if (clock_tick % 30 == 1) {
        int h = 0, m = 0;
        rtc_get_time(&h, &m);
        cached_clock[0] = '0' + ((h / 10) % 10);
        cached_clock[1] = '0' + (h % 10);
        cached_clock[2] = ':';
        cached_clock[3] = '0' + ((m / 10) % 10);
        cached_clock[4] = '0' + (m % 10);
        cached_clock[5] = 0;
    }
}

// ============================================================================
// Завершение работы системы (Shutdown)
// ============================================================================
static void system_shutdown(void) {
    outw(0x4004, 0x3400); // VirtualBox ACPI
    outw(0x604, 0x2000);  // QEMU
    outw(0xB004, 0x2000); // Bochs

    vga_set_mode(VGA_MODE_TEXT_80x25);
    terminal_clear();
    terminal_write_line("==================================================");
    terminal_write_line("   It is now safe to turn off your computer.");
    terminal_write_line("   GraphOS System Halted.");
    terminal_write_line("==================================================");
    __asm__ volatile("cli");
    while (1) {
        __asm__ volatile("hlt");
    }
}

// ============================================================================
// Графический шрифт 6x8
// ============================================================================
static const uint8_t font6x8[128][8] = {
    [' '] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00},
    ['!'] = {0x20,0x20,0x20,0x20,0x00,0x00,0x20,0x00},
    [':'] = {0x00,0x20,0x00,0x00,0x20,0x00,0x00,0x00},
    ['-'] = {0x00,0x00,0x00,0x38,0x00,0x00,0x00,0x00},
    ['.'] = {0x00,0x00,0x00,0x00,0x00,0x20,0x00,0x00},
    ['/'] = {0x08,0x10,0x10,0x20,0x20,0x40,0x40,0x00},
    ['>'] = {0x40,0x20,0x10,0x08,0x10,0x20,0x40,0x00},
    ['_'] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x7C},
    ['x'] = {0x00,0x00,0x24,0x18,0x18,0x24,0x00,0x00},
    ['0'] = {0x38,0x44,0x4C,0x54,0x64,0x44,0x38,0x00},
    ['1'] = {0x10,0x30,0x10,0x10,0x10,0x10,0x38,0x00},
    ['2'] = {0x38,0x44,0x04,0x18,0x20,0x40,0x7C,0x00},
    ['3'] = {0x38,0x44,0x04,0x18,0x04,0x44,0x38,0x00},
    ['4'] = {0x08,0x18,0x28,0x48,0x7C,0x08,0x08,0x00},
    ['5'] = {0x7C,0x40,0x78,0x04,0x04,0x44,0x38,0x00},
    ['6'] = {0x18,0x20,0x40,0x78,0x44,0x44,0x38,0x00},
    ['7'] = {0x7C,0x04,0x08,0x10,0x20,0x20,0x20,0x00},
    ['8'] = {0x38,0x44,0x44,0x38,0x44,0x44,0x38,0x00},
    ['9'] = {0x38,0x44,0x44,0x3C,0x04,0x08,0x30,0x00},
    ['A'] = {0x38,0x44,0x44,0x7C,0x44,0x44,0x44,0x00},
    ['B'] = {0x78,0x44,0x44,0x78,0x44,0x44,0x78,0x00},
    ['C'] = {0x38,0x44,0x40,0x40,0x40,0x44,0x38,0x00},
    ['D'] = {0x78,0x44,0x44,0x44,0x44,0x44,0x78,0x00},
    ['E'] = {0x7C,0x40,0x40,0x78,0x40,0x40,0x7C,0x00},
    ['F'] = {0x7C,0x40,0x40,0x78,0x40,0x40,0x40,0x00},
    ['G'] = {0x38,0x44,0x40,0x4C,0x44,0x44,0x38,0x00},
    ['H'] = {0x44,0x44,0x44,0x7C,0x44,0x44,0x44,0x00},
    ['I'] = {0x38,0x10,0x10,0x10,0x10,0x10,0x38,0x00},
    ['J'] = {0x0C,0x04,0x04,0x04,0x04,0x44,0x38,0x00},
    ['K'] = {0x44,0x48,0x50,0x60,0x50,0x48,0x44,0x00},
    ['L'] = {0x40,0x40,0x40,0x40,0x40,0x40,0x7C,0x00},
    ['M'] = {0x44,0x6C,0x54,0x44,0x44,0x44,0x44,0x00},
    ['N'] = {0x44,0x64,0x54,0x4C,0x44,0x44,0x44,0x00},
    ['O'] = {0x38,0x44,0x44,0x44,0x44,0x44,0x38,0x00},
    ['P'] = {0x78,0x44,0x44,0x78,0x40,0x40,0x40,0x00},
    ['Q'] = {0x38,0x44,0x44,0x44,0x54,0x48,0x34,0x00},
    ['R'] = {0x78,0x44,0x44,0x78,0x50,0x48,0x44,0x00},
    ['S'] = {0x38,0x44,0x40,0x38,0x04,0x44,0x38,0x00},
    ['T'] = {0x7C,0x10,0x10,0x10,0x10,0x10,0x10,0x00},
    ['U'] = {0x44,0x44,0x44,0x44,0x44,0x44,0x38,0x00},
    ['V'] = {0x44,0x44,0x44,0x44,0x28,0x28,0x10,0x00},
    ['W'] = {0x44,0x44,0x44,0x54,0x54,0x6C,0x44,0x00},
    ['X'] = {0x44,0x44,0x28,0x10,0x28,0x44,0x44,0x00},
    ['Y'] = {0x44,0x44,0x28,0x10,0x10,0x10,0x10,0x00},
    ['Z'] = {0x7C,0x04,0x08,0x10,0x20,0x40,0x7C,0x00},
    ['a'] = {0x00,0x00,0x38,0x04,0x3C,0x44,0x3C,0x00},
    ['b'] = {0x40,0x40,0x78,0x44,0x44,0x44,0x78,0x00},
    ['c'] = {0x00,0x00,0x38,0x44,0x40,0x44,0x38,0x00},
    ['d'] = {0x04,0x04,0x3C,0x44,0x44,0x44,0x3C,0x00},
    ['e'] = {0x00,0x00,0x38,0x44,0x7C,0x40,0x38,0x00},
    ['f'] = {0x18,0x24,0x20,0x70,0x20,0x20,0x20,0x00},
    ['g'] = {0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x38},
    ['h'] = {0x40,0x40,0x78,0x44,0x44,0x44,0x44,0x00},
    ['i'] = {0x10,0x00,0x30,0x10,0x10,0x10,0x38,0x00},
    ['j'] = {0x08,0x00,0x18,0x08,0x08,0x08,0x48,0x30},
    ['k'] = {0x40,0x40,0x48,0x50,0x60,0x50,0x48,0x00},
    ['l'] = {0x30,0x10,0x10,0x10,0x10,0x10,0x38,0x00},
    ['m'] = {0x00,0x00,0x74,0x54,0x54,0x54,0x54,0x00},
    ['n'] = {0x00,0x00,0x78,0x44,0x44,0x44,0x44,0x00},
    ['o'] = {0x00,0x00,0x38,0x44,0x44,0x44,0x38,0x00},
    ['p'] = {0x00,0x00,0x78,0x44,0x44,0x78,0x40,0x40},
    ['q'] = {0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x04},
    ['r'] = {0x00,0x00,0x58,0x64,0x40,0x40,0x40,0x00},
    ['s'] = {0x00,0x00,0x3C,0x40,0x38,0x04,0x78,0x00},
    ['t'] = {0x20,0x20,0x70,0x20,0x20,0x24,0x18,0x00},
    ['u'] = {0x00,0x00,0x44,0x44,0x44,0x44,0x38,0x00},
    ['v'] = {0x00,0x00,0x44,0x44,0x28,0x28,0x10,0x00},
    ['w'] = {0x00,0x00,0x44,0x54,0x54,0x6C,0x24,0x00},
    ['y'] = {0x00,0x00,0x44,0x44,0x3C,0x04,0x48,0x30},
    ['z'] = {0x00,0x00,0x7C,0x08,0x10,0x20,0x7C,0x00}
};

static inline void bb_put_pixel(int x, int y, uint8_t color) {
    if ((unsigned)x < 320 && (unsigned)y < 200) {
        backbuffer[y * 320 + x] = color;
    }
}

static inline void bb_fill_rect(int x, int y, int w, int h, uint8_t color) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > 320) w = 320 - x;
    if (y + h > 200) h = 200 - y;
    if (w <= 0 || h <= 0) return;

    for (int r = 0; r < h; r++) {
        uint8_t* row = &backbuffer[(y + r) * 320 + x];
        for (int c = 0; c < w; c++) row[c] = color;
    }
}

static void bb_draw_3d_rect(int x, int y, int w, int h, int pressed) {
    uint8_t top_left = pressed ? 8 : 15;
    uint8_t bot_right = pressed ? 15 : 0;
    uint8_t bot_mid = pressed ? 0 : 8;

    for (int i = 0; i < w; i++) bb_put_pixel(x + i, y, top_left);
    for (int i = 0; i < h; i++) bb_put_pixel(x, y + i, top_left);
    for (int i = 0; i < w; i++) bb_put_pixel(x + i, y + h - 1, bot_right);
    for (int i = 0; i < h; i++) bb_put_pixel(x + w - 1, y + i, bot_right);
    for (int i = 1; i < w - 1; i++) bb_put_pixel(x + i, y + h - 2, bot_mid);
    for (int i = 1; i < h - 1; i++) bb_put_pixel(x + w - 2, y + i, bot_mid);
}

static void bb_draw_char(int x, int y, char ch, uint8_t color) {
    if ((uint8_t)ch >= 128) return;
    const uint8_t* glyph = font6x8[(uint8_t)ch];
    for (int r = 0; r < 8; r++) {
        uint8_t row = glyph[r];
        for (int c = 0; c < 6; c++) {
            if (row & (0x40 >> c)) {
                bb_put_pixel(x + c, y + r, color);
            }
        }
    }
}

static void bb_draw_text(int x, int y, const char* str, uint8_t color) {
    while (*str) {
        bb_draw_char(x, y, *str++, color);
        x += 6;
    }
}

static void bb_draw_sprite(int x, int y, int w, int h, const uint8_t* data) {
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            uint8_t col = data[r * w + c];
            if (col != 0xFF) {
                bb_put_pixel(x + c, y + r, col);
            }
        }
    }
}

static inline void bb_flip(void) {
    uint32_t* src = (uint32_t*)backbuffer;
    volatile uint32_t* dst = (volatile uint32_t*)0xA0000;
    for (int i = 0; i < 16000; i++) dst[i] = src[i];
}

#define MAX_TERM_LINES 8
#define TERM_LINE_LEN 32

static char term_lines[MAX_TERM_LINES][TERM_LINE_LEN];
static int term_num_lines = 0;
static int term_scroll_offset = 0;
static char term_cmd[TERM_LINE_LEN];
static int term_cmd_pos = 0;

static int str_eq(const char* a, const char* b) {
    while (*a && *b) {
        if (*a != *b) return 0;
        a++; b++;
    }
    return (*a == *b);
}

static void str_cpy(char* dst, const char* src, int max) {
    int i = 0;
    while (src[i] && i < max - 1) {
        dst[i] = src[i];
        i++;
    }
    dst[i] = 0;
}

static void term_add_line(const char* s) {
    if (term_num_lines < MAX_TERM_LINES) {
        str_cpy(term_lines[term_num_lines], s, TERM_LINE_LEN);
        term_num_lines++;
        term_scroll_offset = 0;
    } else {
        for (int i = 0; i < MAX_TERM_LINES - 1; i++) {
            str_cpy(term_lines[i], term_lines[i + 1], TERM_LINE_LEN);
        }
        str_cpy(term_lines[MAX_TERM_LINES - 1], s, TERM_LINE_LEN);
    }
}

// Сетка рабочего стола (6 колонок x 4 строки)
#define GRID_START_X 14
#define GRID_START_Y 12
#define GRID_CELL_W  50
#define GRID_CELL_H  42
#define GRID_COLS    6
#define GRID_ROWS    4

typedef struct {
    int id;
    int x, y;
    const char* name;
    const uint8_t* icon_data;
    int selected;
    int dragging;
    int drag_off_x, drag_off_y;
    int orig_x, orig_y;
    int target_win;
} desktop_icon_t;

#define NUM_ICONS 2
static desktop_icon_t d_icons[NUM_ICONS] = {
    {1, 14, 12, "My PC",   my_pc_icon_data,   0, 0, 0, 0, 14, 12, 0},
    {2, 14, 54, "Console", console_icon_data, 0, 0, 0, 0, 14, 54, 1}
};

typedef struct {
    int id;
    int x, y;
    int w, h;
    const char* title;
    int visible;
    int dragging;
    int drag_off_x, drag_off_y;
    int type; // 1 = System Info, 2 = Command Prompt
    int resizing;
} gui_win_t;

static void gui_draw_text_clipped(int x, int y, const char* str, uint8_t color, int max_x) {
    while (*str) {
        if (x + 8 > max_x) break;
        bb_draw_char(x, y, *str, color);
        x += 8;
        str++;
    }
}

static void gui_draw_window(gui_win_t* win, int focused, int cursor_visible) {
    if (!win->visible) return;

    bb_fill_rect(win->x, win->y, win->w, win->h, 7);
    bb_draw_3d_rect(win->x, win->y, win->w, win->h, 0);

    int title_col = focused ? 1 : 8;
    bb_fill_rect(win->x + 3, win->y + 3, win->w - 6, 13, title_col);
    bb_draw_text(win->x + 6, win->y + 6, win->title, 15);

    int bx = win->x + win->w - 15;
    int by = win->y + 4;
    bb_fill_rect(bx, by, 11, 11, 7);
    bb_draw_3d_rect(bx, by, 11, 11, 0);
    bb_draw_text(bx + 3, by + 2, "x", 0);

    if (win->type == 1) {
        int ix = win->x + 5;
        int iy = win->y + 19;
        int iw = win->w - 10;
        int ih = win->h - 25;
        if (iw > 10 && ih > 10) {
            bb_fill_rect(ix, iy, iw, ih, 15);
            bb_draw_3d_rect(ix, iy, iw, ih, 1);

            // CPUID
            char cpu_vendor[17];
            uint32_t eax_out, ebx_out, ecx_out, edx_out;
            __asm__ volatile("cpuid" : "=a"(eax_out), "=b"(ebx_out), "=c"(ecx_out), "=d"(edx_out) : "a"(0));
            *(uint32_t*)&cpu_vendor[0] = ebx_out;
            *(uint32_t*)&cpu_vendor[4] = edx_out;
            *(uint32_t*)&cpu_vendor[8] = ecx_out;
            cpu_vendor[12] = 0;

            char cpu_str[36];
            str_cpy(cpu_str, "CPU: ", 6);
            int ci = 0;
            while (cpu_vendor[ci] && ci < 16) { cpu_str[5 + ci] = cpu_vendor[ci]; ci++; }
            cpu_str[5 + ci] = 0;

            // Аптайм от момента запуска GUI
            uint32_t ut_sec = (timer_ticks() - gui_start_ticks) / 100;
            char up_str[32];
            str_cpy(up_str, "Uptime: ", 9);
            char num_buf[10];
            int nbi = 0;
            uint32_t tmp_sec = ut_sec;
            if (tmp_sec == 0) num_buf[nbi++] = '0';
            else {
                while (tmp_sec > 0 && nbi < 8) {
                    num_buf[nbi++] = '0' + (tmp_sec % 10);
                    tmp_sec /= 10;
                }
            }
            int up_pos = 8;
            for (int k = nbi - 1; k >= 0; k--) up_str[up_pos++] = num_buf[k];
            up_str[up_pos++] = ' '; up_str[up_pos++] = 's'; up_str[up_pos] = 0;

            const char* sys_lines[] = {
                "GraphOS v1.0 Desktop",
                "Kernel: 32-bit Protected Mode",
                "-----------------------------",
                cpu_str,
                "RAM: 128 MB (Free: 114 MB)",
                "Display: VGA 320x200 256c",
                up_str
            };
            uint8_t sys_cols[] = { 0, 8, 8, 0, 8, 8, 1 };
            int num_sys_lines = 7;

            int line_y = iy + 6;
            for (int li = 0; li < num_sys_lines; li++) {
                if (line_y + 8 > iy + ih - 4) break;
                gui_draw_text_clipped(ix + 6, line_y, sys_lines[li], sys_cols[li], ix + iw - 6);
                line_y += 12;
            }
        }
    }

    else if (win->type == 2) {
        int ix = win->x + 5;
        int iy = win->y + 19;
        int iw = win->w - 10;
        int ih = win->h - 25;
        if (iw > 10 && ih > 10) {
            bb_fill_rect(ix, iy, iw, ih, 0);
            bb_draw_3d_rect(ix, iy, iw, ih, 1);

            int max_visible = (ih - 18) / 9;
            if (max_visible < 1) max_visible = 1;
            if (term_scroll_offset > term_num_lines - max_visible) {
                term_scroll_offset = term_num_lines - max_visible;
            }
            if (term_scroll_offset < 0) term_scroll_offset = 0;

            int end_idx = term_num_lines - term_scroll_offset;
            if (end_idx < 0) end_idx = 0;
            int start_idx = end_idx - max_visible;
            if (start_idx < 0) start_idx = 0;

            int max_chars = (iw - 8) / 8;
            int line_y = iy + 4;
            for (int i = start_idx; i < end_idx; i++) {
                if (line_y + 8 <= iy + ih - 13 && max_chars > 0) {
                    char tbuf[48];
                    int c_idx = 0;
                    while (term_lines[i][c_idx] && c_idx < max_chars && c_idx < 46) {
                        tbuf[c_idx] = term_lines[i][c_idx];
                        c_idx++;
                    }
                    tbuf[c_idx] = 0;
                    bb_draw_text(ix + 4, line_y, tbuf, 10);
                    line_y += 9;
                }
            }

            // Индикатор активного скролла
            if (term_scroll_offset > 0 && iw > 60) {
                bb_draw_text(ix + iw - 48, iy + 3, "[^UP]", 14);
            }

            // Поле ввода команд
            if (ih >= 20 && max_chars > 2) {
                bb_draw_text(ix + 4, iy + ih - 11, ">", 10);
                char cmd_disp[36];
                int c_idx = 0;
                int cmd_max = max_chars - 3;
                while (term_cmd[c_idx] && c_idx < cmd_max && c_idx < 34) {
                    cmd_disp[c_idx] = term_cmd[c_idx];
                    c_idx++;
                }
                cmd_disp[c_idx] = 0;
                bb_draw_text(ix + 14, iy + ih - 11, cmd_disp, 10);
                if (cursor_visible && ix + 14 + term_cmd_pos * 8 + 8 <= ix + iw - 4) {
                    bb_fill_rect(ix + 14 + term_cmd_pos * 8, iy + ih - 11, 7, 8, 10);
                }
            }
        }

}


    // Рифленый уголок изменения размера в правом нижнем углу окна
    if (win->w > 20 && win->h > 20) {
        int rx = win->x + win->w - 3;
        int ry = win->y + win->h - 3;
        bb_put_pixel(rx - 1, ry - 1, 8); bb_put_pixel(rx, ry - 1, 15);
        bb_put_pixel(rx - 1, ry, 15);
        bb_put_pixel(rx - 4, ry - 1, 8); bb_put_pixel(rx - 3, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 4, 8); bb_put_pixel(rx - 1, ry - 3, 15);
        bb_put_pixel(rx - 7, ry - 1, 8); bb_put_pixel(rx - 6, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 7, 8); bb_put_pixel(rx - 1, ry - 6, 15);
        bb_put_pixel(rx - 4, ry - 4, 8); bb_put_pixel(rx - 3, ry - 4, 15);
    }
    // Рифленый уголок изменения размера в правом нижнем углу окна
    if (win->w > 20 && win->h > 20) {
        int rx = win->x + win->w - 3;
        int ry = win->y + win->h - 3;
        bb_put_pixel(rx - 1, ry - 1, 8); bb_put_pixel(rx, ry - 1, 15);
        bb_put_pixel(rx - 1, ry, 15);
        bb_put_pixel(rx - 4, ry - 1, 8); bb_put_pixel(rx - 3, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 4, 8); bb_put_pixel(rx - 1, ry - 3, 15);
        bb_put_pixel(rx - 7, ry - 1, 8); bb_put_pixel(rx - 6, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 7, 8); bb_put_pixel(rx - 1, ry - 6, 15);
        bb_put_pixel(rx - 4, ry - 4, 8); bb_put_pixel(rx - 3, ry - 4, 15);
    }
    // Рифленый уголок изменения размера в правом нижнем углу окна
    if (win->w > 20 && win->h > 20) {
        int rx = win->x + win->w - 3;
        int ry = win->y + win->h - 3;
        bb_put_pixel(rx - 1, ry - 1, 8); bb_put_pixel(rx, ry - 1, 15);
        bb_put_pixel(rx - 1, ry, 15);
        bb_put_pixel(rx - 4, ry - 1, 8); bb_put_pixel(rx - 3, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 4, 8); bb_put_pixel(rx - 1, ry - 3, 15);
        bb_put_pixel(rx - 7, ry - 1, 8); bb_put_pixel(rx - 6, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 7, 8); bb_put_pixel(rx - 1, ry - 6, 15);
        bb_put_pixel(rx - 4, ry - 4, 8); bb_put_pixel(rx - 3, ry - 4, 15);
    }
    // Рифленый уголок изменения размера в правом нижнем углу окна
    if (win->w > 20 && win->h > 20) {
        int rx = win->x + win->w - 3;
        int ry = win->y + win->h - 3;
        bb_put_pixel(rx - 1, ry - 1, 8); bb_put_pixel(rx, ry - 1, 15);
        bb_put_pixel(rx - 1, ry, 15);
        bb_put_pixel(rx - 4, ry - 1, 8); bb_put_pixel(rx - 3, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 4, 8); bb_put_pixel(rx - 1, ry - 3, 15);
        bb_put_pixel(rx - 7, ry - 1, 8); bb_put_pixel(rx - 6, ry - 1, 15);
        bb_put_pixel(rx - 1, ry - 7, 8); bb_put_pixel(rx - 1, ry - 6, 15);
        bb_put_pixel(rx - 4, ry - 4, 8); bb_put_pixel(rx - 3, ry - 4, 15);
    }
}

static void bring_window_to_top(int win_idx, int* z_order, int count) {
    int pos = -1;
    for (int i = 0; i < count; i++) {
        if (z_order[i] == win_idx) {
            pos = i;
            break;
        }
    }
    if (pos != -1 && pos < count - 1) {
        for (int i = pos; i < count - 1; i++) {
            z_order[i] = z_order[i + 1];
        }
        z_order[count - 1] = win_idx;
    }
}

static void gui_render_frame(gui_win_t* wins, int* z_order, int mx, int my, const uint8_t sprite[10][8], int start_open, int cursor_visible) {
    // 1. Обои рабочего стола (64000 байт)
    for (int i = 0; i < 64000; i++) {
        backbuffer[i] = bg_wallpaper_data[i];
    }

    // 2. Иконки рабочего стола
    for (int i = 0; i < NUM_ICONS; i++) {
        if (d_icons[i].selected) {
            bb_fill_rect(d_icons[i].x - 2, d_icons[i].y - 2, 20, 20, 1);
        }
        bb_draw_sprite(d_icons[i].x, d_icons[i].y, 16, 16, d_icons[i].icon_data);
        bb_draw_text(d_icons[i].x - 2, d_icons[i].y + 18, d_icons[i].name, 0);
    }

    // 3. Окна в порядке z_order
    for (int i = 0; i < 3; i++) {
        int wid = z_order[i];
        gui_draw_window(&wins[wid], (i == 2), cursor_visible);
    }

    bb_fill_rect(0, 182, 320, 18, 7);
    bb_draw_3d_rect(0, 182, 320, 18, 0);

    // 1. Кнопка Start
    if (start_open) {
        bb_fill_rect(2, 184, 52, 14, 7);
        bb_draw_3d_rect(2, 184, 52, 14, 1);
        bb_draw_sprite(5, 184, 16, 16, menu_icon_data);
        bb_draw_text(23, 188, "Start", 0);
    } else {
        bb_fill_rect(2, 184, 52, 14, 7);
        bb_draw_3d_rect(2, 184, 52, 14, 0);
        bb_draw_sprite(4, 183, 16, 16, menu_icon_data);
        bb_draw_text(22, 187, "Start", 0);
    }

    // 2. Часы в правом углу панели задач
    bb_draw_3d_rect(266, 184, 52, 14, 1);
    bb_draw_text(272, 187, cached_clock, 0);

    // 3. Выпадающее меню Start (когда открыто)
    if (start_open) {
        int sm_x = 2;
        int sm_y = 100;
        int sm_w = 120;
        int sm_h = 82;

        bb_fill_rect(sm_x, sm_y, sm_w, sm_h, 7);
        bb_draw_3d_rect(sm_x, sm_y, sm_w, sm_h, 0);

        // Боковая плашка GraphOS
        bb_fill_rect(sm_x + 2, sm_y + 2, 16, sm_h - 4, 1);
        bb_draw_char(sm_x + 7, sm_y + 8,  'G', 15);
        bb_draw_char(sm_x + 7, sm_y + 17, 'r', 15);
        bb_draw_char(sm_x + 7, sm_y + 26, 'a', 15);
        bb_draw_char(sm_x + 7, sm_y + 35, 'p', 15);
        bb_draw_char(sm_x + 7, sm_y + 44, 'h', 15);
        bb_draw_char(sm_x + 7, sm_y + 55, 'O', 14);
        bb_draw_char(sm_x + 7, sm_y + 64, 'S', 14);

        int item_x = sm_x + 20;
        int item_w = sm_w - 23;

        // Console
        int h0 = (mx >= item_x && mx < item_x + item_w && my >= sm_y + 4 && my < sm_y + 21);
        if (h0) bb_fill_rect(item_x, sm_y + 4, item_w, 17, 1);
        bb_draw_sprite(item_x + 2, sm_y + 4, 16, 16, console_icon_data);
        bb_draw_text(item_x + 22, sm_y + 9, "Console", h0 ? 15 : 0);

        // System Info
        int h1 = (mx >= item_x && mx < item_x + item_w && my >= sm_y + 22 && my < sm_y + 39);
        if (h1) bb_fill_rect(item_x, sm_y + 22, item_w, 17, 1);
        bb_draw_sprite(item_x + 2, sm_y + 22, 16, 16, my_pc_icon_data);
        bb_draw_text(item_x + 22, sm_y + 27, "System Info", h1 ? 15 : 0);

        // Task Manager
        int h2 = (mx >= item_x && mx < item_x + item_w && my >= sm_y + 40 && my < sm_y + 57);
        if (h2) bb_fill_rect(item_x, sm_y + 40, item_w, 17, 1);
        bb_draw_sprite(item_x + 2, sm_y + 40, 16, 16, menu_icon_data);
        bb_draw_text(item_x + 22, sm_y + 45, "Task Manager", h2 ? 15 : 0);

        // Разделитель
        bb_fill_rect(item_x, sm_y + 59, item_w, 1, 8);
        bb_fill_rect(item_x, sm_y + 60, item_w, 1, 15);

        // Shutdown
        int h3 = (mx >= item_x && mx < item_x + item_w && my >= sm_y + 62 && my < sm_y + 79);
        if (h3) bb_fill_rect(item_x, sm_y + 62, item_w, 17, 1);
        bb_draw_text(item_x + 22, sm_y + 67, "Shutdown", h3 ? 15 : 0);
    }

    for (int r = 0; r < 10; r++) {
        for (int c = 0; c < 8; c++) {
            if (mx + c < 320 && my + r < 200) {
                if (sprite[r][c] == 1) bb_put_pixel(mx + c, my + r, 0);
                else if (sprite[r][c] == 2) bb_put_pixel(mx + c, my + r, 15);
            }
        }
    }

    bb_flip();
}

static void launch_gui(void) {
    terminal_write_line("Launching GraphOS GUI Desktop...");
    vga_init();
    vga_set_mode(VGA_MODE_GRAPHICS_320x200);
    vga_load_palette(vga_dac_palette);

    term_num_lines = 0;
    term_scroll_offset = 0;
    term_cmd_pos = 0;
    term_cmd[0] = 0;
    term_add_line("GraphOS Shell v1.0");
    term_add_line("Type 'help' for commands");
    gui_win_t wins[3] = {
        {1, 20, 18, 230, 115, "System Info", 0, 0, 0, 0, 1, 0},
        {2, 50, 25, 220, 115, "Command Prompt", 0, 0, 0, 0, 2, 0},
        {3, 40, 22, 210, 125, "Task Manager", 0, 0, 0, 0, 3, 0}
    };
    int z_order[3] = {0, 1, 2};

    static const uint8_t cursor_sprite[10][8] = {
        {1, 0, 0, 0, 0, 0, 0, 0},
        {1, 1, 0, 0, 0, 0, 0, 0},
        {1, 2, 1, 0, 0, 0, 0, 0},
        {1, 2, 2, 1, 0, 0, 0, 0},
        {1, 2, 2, 2, 1, 0, 0, 0},
        {1, 2, 2, 2, 2, 1, 0, 0},
        {1, 2, 2, 2, 2, 2, 1, 0},
        {1, 2, 2, 1, 1, 1, 0, 0},
        {1, 1, 2, 1, 0, 0, 0, 0},
        {1, 0, 0, 1, 1, 0, 0, 0}
    };

    int cur_x = 160, cur_y = 100;
    int start_menu_open = 0;
    int cursor_visible = 1;

    pic_clear_mask(2);
    pic_clear_mask(12);
    __asm__ volatile("sti");

    gui_start_ticks = timer_ticks();
    update_clock();
    gui_render_frame(wins, z_order, cur_x, cur_y, cursor_sprite, start_menu_open, cursor_visible);

    while (1) {
        mouse_poll();
        int needs_redraw = 0;

        int mx = 0, my = 0;
        mouse_get_position(&mx, &my);

        int left_down = (mouse_get_buttons() & 1);
        static int prev_left = 0;
        int left_pressed = (left_down && !prev_left);
        int left_released = (!left_down && prev_left);
        prev_left = left_down;

        static uint32_t last_clock = 0;
        uint32_t t = timer_ticks();
        if (t - last_clock >= 100) {
            last_clock = t;
            update_clock();
            needs_redraw = 1;
        }

        // Обработка клика мыши
        if (left_pressed) {
            if (mx >= 0 && mx <= 55 && my >= 182 && my <= 199) {
                start_menu_open = !start_menu_open;
                needs_redraw = 1;
            } else if (start_menu_open && mx >= 2 && mx <= 122 && my >= 100 && my <= 182) {
                if (my >= 104 && my < 121) {
                    wins[1].visible = 1;
                    bring_window_to_top(1, z_order, 3);
                    start_menu_open = 0;
                    needs_redraw = 1;
                } else if (my >= 122 && my < 139) {
                    wins[0].visible = 1;
                    bring_window_to_top(0, z_order, 3);
                    start_menu_open = 0;
                    needs_redraw = 1;
                } else if (my >= 140 && my < 157) {
                    wins[2].visible = 1;
                    bring_window_to_top(2, z_order, 3);
                    start_menu_open = 0;
                    needs_redraw = 1;
                } else if (my >= 162 && my < 179) {
                    system_shutdown();
                }
            } else {
                if (start_menu_open) {
                    start_menu_open = 0;
                    needs_redraw = 1;
                }

                int clicked_win = -1;
                for (int i = 2; i >= 0; i--) {
                    int wid = z_order[i];
                    if (wins[wid].visible &&
                        mx >= wins[wid].x && mx < wins[wid].x + wins[wid].w &&
                        my >= wins[wid].y && my < wins[wid].y + wins[wid].h) {
                        clicked_win = wid;
                        break;
                    }
                }

                if (clicked_win != -1) {
                    bring_window_to_top(clicked_win, z_order, 3);
                    gui_win_t* top = &wins[clicked_win];
                    needs_redraw = 1;

                    int bx = top->x + top->w - 15;
                    int by = top->y + 4;
                    if (mx >= bx && mx < bx + 11 && my >= by && my < by + 11) {
                        top->visible = 0;
                    } else if (mx >= top->x + top->w - 12 && my >= top->y + top->h - 12) {
                        top->resizing = 1;
                    } else if (my >= top->y && my < top->y + 18) {
                        top->dragging = 1;
                        top->drag_off_x = mx - top->x;
                        top->drag_off_y = my - top->y;
                    }
                } else {
                    int clicked_icon = -1;
                    for (int i = 0; i < NUM_ICONS; i++) {
                        if (mx >= d_icons[i].x && mx < d_icons[i].x + 32 &&
                            my >= d_icons[i].y && my < d_icons[i].y + 32) {
                            clicked_icon = i;
                            break;
                        }
                    }

                    if (clicked_icon != -1) {
                        if (d_icons[clicked_icon].selected) {
                            wins[d_icons[clicked_icon].target_win].visible = 1;
                            bring_window_to_top(d_icons[clicked_icon].target_win, z_order, 3);
                        } else {
                            for (int k = 0; k < NUM_ICONS; k++) d_icons[k].selected = 0;
                            d_icons[clicked_icon].selected = 1;
                        }
                        d_icons[clicked_icon].dragging = 1;
                        d_icons[clicked_icon].drag_off_x = mx - d_icons[clicked_icon].x;
                        d_icons[clicked_icon].drag_off_y = my - d_icons[clicked_icon].y;
                        needs_redraw = 1;
                    } else {
                        for (int k = 0; k < NUM_ICONS; k++) {
                            if (d_icons[k].selected) {
                                d_icons[k].selected = 0;
                                needs_redraw = 1;
                            }
                        }
                    }
                }
            }
        }

        // Перетаскивание и изменение размера окон
        if (left_down) {
            for (int i = 0; i < 3; i++) {
                if (wins[i].dragging) {
                    int nx = mx - wins[i].drag_off_x;
                    int ny = my - wins[i].drag_off_y;
                    if (nx < 0) nx = 0;
                    if (ny < 0) ny = 0;
                    if (nx > 320 - 40) nx = 320 - 40;
                    if (ny > 182 - 20) ny = 182 - 20;
                    if (nx != wins[i].x || ny != wins[i].y) {
                        wins[i].x = nx;
                        wins[i].y = ny;
                        needs_redraw = 1;
                    }
                }
                if (wins[i].resizing) {
                    int nw = mx - wins[i].x;
                    int nh = my - wins[i].y;
                    if (nw < 75) nw = 75;
                    if (nh < 45) nh = 45;
                    if (wins[i].x + nw > 320) nw = 320 - wins[i].x;
                    if (wins[i].y + nh > 182) nh = 182 - wins[i].y;
                    if (nw != wins[i].w || nh != wins[i].h) {
                        wins[i].w = nw;
                        wins[i].h = nh;
                        needs_redraw = 1;
                    }
                }
            }
            for (int i = 0; i < NUM_ICONS; i++) {
                if (d_icons[i].dragging) {
                    int nx = mx - d_icons[i].drag_off_x;
                    int ny = my - d_icons[i].drag_off_y;
                    if (nx >= 0 && nx < 290 && ny >= 0 && ny < 155) {
                        d_icons[i].x = nx;
                        d_icons[i].y = ny;
                        needs_redraw = 1;
                    }
                }
            }
        }

        if (left_released) {
            for (int i = 0; i < 3; i++) {
                wins[i].dragging = 0;
                wins[i].resizing = 0;
            }
            for (int i = 0; i < NUM_ICONS; i++) d_icons[i].dragging = 0;
        }

        // Обработка клавиатуры
        while (keyboard_has_input()) {
            char ch = keyboard_getchar();
            gui_win_t* top_win = &wins[z_order[2]];

            if (top_win->visible && top_win->type == 2) {
                if (ch == 17) {
                    term_scroll_offset++;
                    needs_redraw = 1;
                } else if (ch == 18) {
                    if (term_scroll_offset > 0) term_scroll_offset--;
                    needs_redraw = 1;
                } else if (ch == 10) {
                    if (term_cmd_pos > 0) {
                        char echo_buf[TERM_LINE_LEN];
                        echo_buf[0] = '>';
                        echo_buf[1] = ' ';
                        str_cpy(&echo_buf[2], term_cmd, TERM_LINE_LEN - 2);
                        term_add_line(echo_buf);

                        if (str_eq(term_cmd, "taskmgr") || str_eq(term_cmd, "tasks")) {
                            wins[2].visible = 1;
                            bring_window_to_top(2, z_order, 3);
                            term_add_line("Opening Task Manager...");
                        } else if (str_eq(term_cmd, "help")) {
                            term_add_line("Commands: help, clear,");
                            term_add_line("mem, ps, info, exit, halt");
                        } else if (str_eq(term_cmd, "clear")) {
                            term_num_lines = 0;
                        } else if (str_eq(term_cmd, "mem")) {
                            term_add_line("Total: 32 MB");
                            term_add_line("Free:  24 MB");
                        } else if (str_eq(term_cmd, "ps")) {
                            wins[2].visible = 1;
                            bring_window_to_top(2, z_order, 3);
                        } else if (str_eq(term_cmd, "info")) {
                            wins[0].visible = 1;
                            bring_window_to_top(0, z_order, 3);
                        } else if (str_eq(term_cmd, "exit") || str_eq(term_cmd, "halt")) {
                            system_shutdown();
                        } else {
                            term_add_line("Unknown command");
                        }
                        term_cmd_pos = 0;
                        term_cmd[0] = 0;
                        needs_redraw = 1;
                    }
                } else if (ch == '\b') {
                    if (term_cmd_pos > 0) {
                        term_cmd_pos--;
                        term_cmd[term_cmd_pos] = 0;
                        needs_redraw = 1;
                    }
                } else if (ch >= 32 && ch <= 126) {
                    if (term_cmd_pos < TERM_LINE_LEN - 1) {
                        term_cmd[term_cmd_pos++] = ch;
                        term_cmd[term_cmd_pos] = 0;
                        needs_redraw = 1;
                    }
                }
            } else {
                if (ch == 27 || ch == 'q') {
                    if (start_menu_open) {
                        start_menu_open = 0;
                        needs_redraw = 1;
                    } else {
                        system_shutdown();
                    }
                }
            }
        }

        uint32_t now_ticks = timer_ticks();
        int new_cursor_visible = ((now_ticks / 35) % 2) == 0;
        if (new_cursor_visible != cursor_visible) {
            cursor_visible = new_cursor_visible;
            gui_win_t* top_win = &wins[z_order[2]];
            if (top_win->visible && top_win->type == 2) {
                needs_redraw = 1;
            }
        }

        if (start_menu_open && mx >= 2 && mx <= 122 && my >= 100 && my <= 182) {
            needs_redraw = 1;
        }

        if (needs_redraw || mx != cur_x || my != cur_y) {
            cur_x = mx;
            cur_y = my;
            gui_render_frame(wins, z_order, cur_x, cur_y, cursor_sprite, start_menu_open, cursor_visible);
        }

        vga_vsync_wait();
    }
}

void kernel_main(void) {
    terminal_write_line("");
    terminal_write_line("========================================");
    terminal_write_line("       GraphOS v1.0 - Kernel Ready");
    terminal_write_line("========================================");
    terminal_write_line("");
    terminal_write_line("Phase 2 (OS Kernel) - COMPLETE!");
    terminal_write_line("");

    // Инициализация GDT
    init_gdt();
    terminal_write_line("[OK] GDT initialized");

    // Инициализация IDT
    init_idt();
    terminal_write_line("[OK] IDT initialized");

    // Инициализация ISR
    init_isr();
    terminal_write_line("[OK] ISR initialized");

    // Инициализация PIC
    init_pic();
    terminal_write_line("[OK] PIC initialized");

    // Инициализация таймера (100 Hz)
    init_timer(100);
    terminal_write_line("[OK] Timer initialized (100 Hz)");

    // Инициализация клавиатуры
    init_keyboard();
    terminal_write_line("[OK] Keyboard initialized");

    mouse_init();
    terminal_write_line("[OK] Mouse initialized");

    // Инициализация Physical Memory Manager
    // Предполагаем 32MB RAM для демонстрации
    pmm_init(32 * 1024);

    // Инициализация Paging
    paging_init();

    // Включить paging
    paging_enable();

    // Инициализация Heap (1MB heap starting at 8MB)
    heap_init(0x800000, 1024 * 1024);

    // Инициализация Process Management
    scheduler_init();
    process_init();

    // Инициализация System Calls
    syscall_init();

    // Инициализация File System
    vfs_init();
    ide_init();

    // Включить прерывания
    __asm__ volatile("sti");
    terminal_write_line("[OK] Interrupts enabled");

    terminal_write_line("");
    terminal_write_line("System Information:");
    terminal_write_line("  Architecture: x86 (32-bit Protected Mode)");
    terminal_write_line("  Boot method: Custom bootloader");
    terminal_write_line("");

    terminal_write_line("Kernel Status:");
    terminal_write_line("  [OK] Bootloader loaded kernel");
    terminal_write_line("  [OK] Protected mode enabled");
    terminal_write_line("  [OK] VGA text mode active");
    terminal_write_line("  [OK] Interrupts working");
    terminal_write_line("  [OK] Timer ticking");
    terminal_write_line("  [OK] Keyboard responsive");
    terminal_write_line("");

    terminal_write_line("Phase 1 Complete!");
    terminal_write_line("  [OK] GDT - Global Descriptor Table");
    terminal_write_line("  [OK] IDT - Interrupt Descriptor Table");
    terminal_write_line("  [OK] ISR - Interrupt Service Routines");
    terminal_write_line("  [OK] PIC - Programmable Interrupt Controller");
    terminal_write_line("  [OK] PIT - Timer (100 Hz)");
    terminal_write_line("  [OK] PS/2 Keyboard Driver");
    terminal_write_line("");

    terminal_write_line("Phase 2 Complete! All subsystems operational:");
    terminal_write_line("  [OK] PMM - Physical Memory Manager");
    terminal_write_line("  [OK] Paging - Virtual Memory");
    terminal_write_line("  [OK] Heap - Dynamic Memory (malloc/free)");
    terminal_write_line("  [OK] Processes - Task Management");
    terminal_write_line("  [OK] System Calls - int 0x80 interface");
    terminal_write_line("  [OK] File System - VFS & IDE Driver");
    terminal_write_line("  [OK] Synchronization - Locks & Semaphores");
    terminal_write_line("  [OK] Testing - All tests passing");
    terminal_write_line("");

    terminal_write_line("=== GraphOS Shell v1.0 ===");
    terminal_write_line("");
    terminal_write_line(">>> Type \'gui\' to start Graphical Desktop <<<");
    terminal_write_line("");
    terminal_write_line("Type your commands. Try:");
    terminal_write_line("  help     - Show available commands");
    terminal_write_line("  clear    - Clear screen");
    terminal_write_line("  mem      - Memory statistics");
    terminal_write_line("  ps       - List processes");
    terminal_write_line("");
    terminal_write("> ");

    // Главный цикл - простой shell
    #define CMD_BUFFER_SIZE 256
    char cmd_buffer[CMD_BUFFER_SIZE];
    uint32_t cmd_pos = 0;

    while (1) {
        if (keyboard_has_input()) {
            char c = keyboard_getchar();

            if (c == '\n') {
                terminal_putchar('\n');

                // Завершить строку
                cmd_buffer[cmd_pos] = '\0';

                // Обработать команду
                if (cmd_pos > 0) {
                    // help
                    if (cmd_buffer[0] == 'h' && cmd_buffer[1] == 'e' &&
                        cmd_buffer[2] == 'l' && cmd_buffer[3] == 'p' && cmd_buffer[4] == '\0') {
                        terminal_write_line("Available commands:");
                        terminal_write_line("  help     - Show this help");
                        terminal_write_line("  gui      - Launch Graphical Desktop");
                        terminal_write_line("  clear    - Clear the screen");
                        terminal_write_line("  uptime   - Show system uptime");
                        terminal_write_line("  test     - Run hardware test");
                        terminal_write_line("  echo     - Echo your text");
                        terminal_write_line("  info     - System information");
                        terminal_write_line("  mem      - Memory statistics");
                        terminal_write_line("  memtest  - Test memory allocator");
                        terminal_write_line("  pgtest   - Test paging system");
                        terminal_write_line("  heaptest - Test heap allocator");
                        terminal_write_line("  ps       - List all processes");
                        terminal_write_line("  syscall  - Test system calls");
                        terminal_write_line("  ls       - List files in root directory");
                        terminal_write_line("  cat      - Read a file");
                        terminal_write_line("  locktest - Test synchronization primitives");
                    }
                    // gui
                else if (cmd_buffer[0] == 'g' && cmd_buffer[1] == 'u' &&
                         cmd_buffer[2] == 'i' && cmd_buffer[3] == 0) {
                    launch_gui();
                }

                // clear
                    else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'l' &&
                             cmd_buffer[2] == 'e' && cmd_buffer[3] == 'a' &&
                             cmd_buffer[4] == 'r' && cmd_buffer[5] == '\0') {
                        terminal_clear();
                        terminal_write_line("=== GraphOS Shell v0.1 ===");
                        terminal_write_line("");
                    }
                    // uptime
                    else if (cmd_buffer[0] == 'u' && cmd_buffer[1] == 'p' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == 'i' &&
                             cmd_buffer[4] == 'm' && cmd_buffer[5] == 'e' && cmd_buffer[6] == '\0') {
                        terminal_write("System uptime: ");
                        print_dec(timer_ticks() / 100);
                        terminal_write_line(" seconds");
                    }
                    // test
                    else if (cmd_buffer[0] == 't' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 's' && cmd_buffer[3] == 't' && cmd_buffer[4] == '\0') {
                        terminal_write_line("Running timer test...");
                        terminal_write("Waiting 2 seconds... ");
                        uint32_t start = timer_ticks();
                        timer_wait(200);
                        terminal_write("Done! (");
                        print_dec(timer_ticks() - start);
                        terminal_write_line(" ticks)");
                    }
                    // info
                    else if (cmd_buffer[0] == 'i' && cmd_buffer[1] == 'n' &&
                             cmd_buffer[2] == 'f' && cmd_buffer[3] == 'o' && cmd_buffer[4] == '\0') {
                        terminal_write_line("GraphOS v0.4 - Phase 2 Started");
                        terminal_write_line("Architecture: x86 (32-bit)");
                        terminal_write_line("Boot: Custom bootloader");
                        terminal_write("Uptime: ");
                        print_dec(timer_ticks() / 100);
                        terminal_write_line(" seconds");

                        pmm_info_t mem_info;
                        pmm_get_info(&mem_info);
                        terminal_write("Memory: ");
                        print_dec(mem_info.free_memory);
                        terminal_write(" KB free / ");
                        print_dec(mem_info.total_memory);
                        terminal_write_line(" KB total");

                        uint32_t heap_alloc, heap_free, heap_blocks;
                        heap_get_stats(&heap_alloc, &heap_free, &heap_blocks);
                        terminal_write("Heap: ");
                        print_dec(heap_alloc / 1024);
                        terminal_write(" KB used, ");
                        print_dec(heap_blocks);
                        terminal_write_line(" blocks");
                    }
                    // mem (new command)
                    else if (cmd_buffer[0] == 'm' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'm' && cmd_buffer[3] == '\0') {
                        pmm_info_t mem_info;
                        pmm_get_info(&mem_info);

                        terminal_write_line("Memory Statistics:");
                        terminal_write("  Total:      ");
                        print_dec(mem_info.total_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Used:       ");
                        print_dec(mem_info.used_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Free:       ");
                        print_dec(mem_info.free_memory);
                        terminal_write_line(" KB");

                        terminal_write("  Pages:      ");
                        print_dec(mem_info.used_pages);
                        terminal_write(" / ");
                        print_dec(mem_info.total_pages);
                        terminal_write_line(" used");
                    }
                    // memtest (new command)
                    else if (cmd_buffer[0] == 'm' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'm' && cmd_buffer[3] == 't' &&
                             cmd_buffer[4] == 'e' && cmd_buffer[5] == 's' &&
                             cmd_buffer[6] == 't' && cmd_buffer[7] == '\0') {
                        terminal_write_line("Memory Allocation Test:");

                        terminal_write("  Allocating 10 pages... ");
                        void* pages[10];
                        for (int i = 0; i < 10; i++) {
                            pages[i] = pmm_alloc_page();
                        }
                        terminal_write_line("OK");

                        pmm_info_t info;
                        pmm_get_info(&info);
                        terminal_write("  Used pages: ");
                        print_dec(info.used_pages);
                        terminal_write_line("");

                        terminal_write("  Freeing 5 pages... ");
                        for (int i = 0; i < 5; i++) {
                            pmm_free_page(pages[i]);
                        }
                        terminal_write_line("OK");

                        pmm_get_info(&info);
                        terminal_write("  Used pages: ");
                        print_dec(info.used_pages);
                        terminal_write_line("");

                        terminal_write("  Freeing remaining... ");
                        for (int i = 5; i < 10; i++) {
                            pmm_free_page(pages[i]);
                        }
                        terminal_write_line("OK");

                        terminal_write_line("  Test complete!");
                    }
                    // pgtest (new command)
                    else if (cmd_buffer[0] == 'p' && cmd_buffer[1] == 'g' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == 'e' &&
                             cmd_buffer[4] == 's' && cmd_buffer[5] == 't' && cmd_buffer[6] == '\0') {
                        terminal_write_line("Paging Test:");

                        // Тест 1: Проверить identity mapping
                        terminal_write("  Testing identity mapping... ");
                        uint32_t virt = 0x100000; // 1MB
                        uint32_t phys = paging_get_physical(virt);
                        if (phys == virt) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write("FAIL (expected ");
                            print_hex(virt);
                            terminal_write(", got ");
                            print_hex(phys);
                            terminal_write_line(")");
                        }

                        // Тест 2: Мапить новую страницу
                        terminal_write("  Mapping new page... ");
                        uint32_t new_virt = 0x900000; // 9MB
                        uint32_t new_phys = (uint32_t)pmm_alloc_page();
                        paging_map_page(new_virt, new_phys, PAGE_PRESENT | PAGE_RW);
                        terminal_write_line("OK");

                        // Тест 3: Проверить новый маппинг
                        terminal_write("  Verifying new mapping... ");
                        uint32_t mapped_phys = paging_get_physical(new_virt);
                        if (mapped_phys == new_phys) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Тест 4: Анмапить
                        terminal_write("  Unmapping page... ");
                        paging_unmap_page(new_virt);
                        terminal_write_line("OK");

                        // Тест 5: Проверить анмаппинг
                        terminal_write("  Verifying unmapping... ");
                        uint32_t unmapped = paging_get_physical(new_virt);
                        if (unmapped == 0) {
                            terminal_write_line("OK");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        pmm_free_page((void*)new_phys);
                        terminal_write_line("  Test complete!");
                    }
                    // heaptest (new command)
                    else if (cmd_buffer[0] == 'h' && cmd_buffer[1] == 'e' &&
                             cmd_buffer[2] == 'a' && cmd_buffer[3] == 'p' &&
                             cmd_buffer[4] == 't' && cmd_buffer[5] == 'e' &&
                             cmd_buffer[6] == 's' && cmd_buffer[7] == 't' && cmd_buffer[8] == '\0') {
                        terminal_write_line("Heap Allocator Test:");

                        // Test 1: Simple allocation
                        terminal_write("  Allocating 100 bytes... ");
                        void* ptr1 = kmalloc(100);
                        if (ptr1) {
                            terminal_write("OK at ");
                            print_hex((uint32_t)ptr1);
                            terminal_write_line("");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Test 2: Multiple allocations
                        terminal_write("  Allocating 200, 300, 400 bytes... ");
                        void* ptr2 = kmalloc(200);
                        void* ptr3 = kmalloc(300);
                        void* ptr4 = kmalloc(400);
                        terminal_write_line("OK");

                        // Test 3: Stats
                        uint32_t allocated, free, blocks;
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Allocated: ");
                        print_dec(allocated);
                        terminal_write(" bytes, Blocks: ");
                        print_dec(blocks);
                        terminal_write_line("");

                        // Test 4: Free some
                        terminal_write("  Freeing 200 and 400 byte blocks... ");
                        kfree(ptr2);
                        kfree(ptr4);
                        terminal_write_line("OK");

                        // Test 5: Stats after free
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Allocated: ");
                        print_dec(allocated);
                        terminal_write(" bytes, Blocks: ");
                        print_dec(blocks);
                        terminal_write_line("");

                        // Test 6: Realloc
                        terminal_write("  Reallocating 100 -> 500 bytes... ");
                        void* ptr5 = krealloc(ptr1, 500);
                        if (ptr5) {
                            terminal_write("OK at ");
                            print_hex((uint32_t)ptr5);
                            terminal_write_line("");
                        } else {
                            terminal_write_line("FAIL");
                        }

                        // Test 7: Cleanup
                        terminal_write("  Cleaning up... ");
                        kfree(ptr3);
                        kfree(ptr5);
                        terminal_write_line("OK");

                        // Final stats
                        heap_get_stats(&allocated, &free, &blocks);
                        terminal_write("  Final: ");
                        print_dec(allocated);
                        terminal_write(" bytes allocated, ");
                        print_dec(blocks);
                        terminal_write_line(" blocks");

                        terminal_write_line("  Test complete!");
                    }
                    // ps (process list)
                    else if (cmd_buffer[0] == 'p' && cmd_buffer[1] == 's' && cmd_buffer[2] == '\0') {
                        process_list();
                    }
                    // syscall test
                    else if (cmd_buffer[0] == 's' && cmd_buffer[1] == 'y' &&
                             cmd_buffer[2] == 's' && cmd_buffer[3] == 'c' &&
                             cmd_buffer[4] == 'a' && cmd_buffer[5] == 'l' &&
                             cmd_buffer[6] == 'l' && cmd_buffer[7] == '\0') {
                        terminal_write_line("System Call Test:");

                        // Test getpid
                        terminal_write("  Testing getpid... ");
                        uint32_t pid;
                        __asm__ volatile(
                            "mov $13, %%eax\n"  // SYS_GETPID
                            "int $0x80\n"
                            "mov %%eax, %0"
                            : "=r"(pid)
                            :
                            : "eax"
                        );
                        terminal_write("PID = ");
                        print_dec(pid);
                        terminal_write_line("");

                        // Test yield
                        terminal_write_line("  Testing yield... ");
                        __asm__ volatile(
                            "mov $16, %%eax\n"  // SYS_YIELD
                            "int $0x80"
                            :
                            :
                            : "eax"
                        );
                        terminal_write_line("  OK - returned from yield");

                        terminal_write_line("  Test complete!");
                    }
                    // ls (list files)
                    else if (cmd_buffer[0] == 'l' && cmd_buffer[1] == 's' && cmd_buffer[2] == '\0') {
                        if (!vfs_root) {
                            terminal_write_line("No filesystem mounted");
                        } else {
                            terminal_write_line("Files in root directory:");
                            uint32_t i = 0;
                            while (1) {
                                dirent_t* dirent = vfs_readdir(vfs_root, i);
                                if (!dirent) {
                                    break;
                                }
                                terminal_write("  ");
                                terminal_write_line(dirent->name);
                                kfree(dirent);
                                i++;
                            }
                        }
                    }
                    // cat <filename>
                    else if (cmd_buffer[0] == 'c' && cmd_buffer[1] == 'a' &&
                             cmd_buffer[2] == 't' && cmd_buffer[3] == ' ') {
                        if (!vfs_root) {
                            terminal_write_line("No filesystem mounted");
                        } else {
                            // Extract filename
                            char filename[64];
                            uint32_t j = 0;
                            for (uint32_t i = 4; i < cmd_pos && j < 63; i++, j++) {
                                filename[j] = cmd_buffer[i];
                            }
                            filename[j] = '\0';

                            // Find file
                            vfs_node_t* file = vfs_finddir(vfs_root, filename);
                            if (!file) {
                                terminal_write("File not found: ");
                                terminal_write_line(filename);
                            } else {
                                // Read file
                                uint8_t buffer[512];
                                uint32_t bytes_read = vfs_read(file, 0, file->length, buffer);

                                // Print content
                                for (uint32_t i = 0; i < bytes_read; i++) {
                                    terminal_putchar((char)buffer[i]);
                                }
                                terminal_putchar('\n');
                            }
                        }
                    }
                    // locktest (synchronization test)
                    else if (cmd_buffer[0] == 'l' && cmd_buffer[1] == 'o' &&
                             cmd_buffer[2] == 'c' && cmd_buffer[3] == 'k' &&
                             cmd_buffer[4] == 't' && cmd_buffer[5] == 'e' &&
                             cmd_buffer[6] == 's' && cmd_buffer[7] == 't' && cmd_buffer[8] == '\0') {
                        terminal_write_line("Synchronization Test:");

                        // Test spinlock
                        terminal_write_line("  Testing spinlock...");
                        spinlock_t spin;
                        spinlock_init(&spin);

                        spinlock_acquire(&spin);
                        terminal_write("    Lock acquired, ");

                        if (!spinlock_try_acquire(&spin)) {
                            terminal_write_line("try_acquire failed (correct)");
                        } else {
                            terminal_write_line("ERROR: try_acquire succeeded!");
                        }

                        spinlock_release(&spin);
                        terminal_write_line("    Lock released");

                        // Test mutex
                        terminal_write_line("  Testing mutex...");
                        mutex_t mtx;
                        mutex_init(&mtx);

                        mutex_lock(&mtx);
                        terminal_write("    Mutex locked, ");

                        if (!mutex_try_lock(&mtx)) {
                            terminal_write_line("try_lock failed (correct)");
                        } else {
                            terminal_write_line("ERROR: try_lock succeeded!");
                        }

                        mutex_unlock(&mtx);
                        terminal_write_line("    Mutex unlocked");

                        // Test semaphore
                        terminal_write_line("  Testing semaphore...");
                        semaphore_t sem;
                        semaphore_init(&sem, 2);

                        terminal_write("    Initial value: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        semaphore_wait(&sem);
                        terminal_write("    After wait: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        semaphore_signal(&sem);
                        terminal_write("    After signal: ");
                        print_dec(semaphore_get_value(&sem));
                        terminal_write_line("");

                        terminal_write_line("  Test complete!");
                    }
                    // echo
                    else if (cmd_buffer[0] == 'e' && cmd_buffer[1] == 'c' &&
                             cmd_buffer[2] == 'h' && cmd_buffer[3] == 'o' && cmd_buffer[4] == ' ') {
                        // Вывести всё после "echo "
                        for (uint32_t i = 5; i < cmd_pos; i++) {
                            terminal_putchar(cmd_buffer[i]);
                        }
                        terminal_putchar('\n');
                    }
                    else {
                        terminal_write("Unknown command: ");
                        terminal_write_line(cmd_buffer);
                        terminal_write_line("Type 'help' for available commands");
                    }
                }

                terminal_write("> ");
                cmd_pos = 0;
            }
            else if (c == '') {
            if (cmd_pos > 0) {
                cmd_pos--;
                terminal_putchar('');
            }
        }
            else {
                // Обычный символ
                if (cmd_pos < CMD_BUFFER_SIZE - 1) {
                    cmd_buffer[cmd_pos++] = c;
                }
            }
        }

        __asm__ volatile("hlt");
    }
}

void terminal_write_hex(uint32_t val) {
char hex_chars[] = "0123456789ABCDEF";
terminal_putchar('0');
terminal_putchar('x');
for (int i = 28; i >= 0; i -= 4) {
    terminal_putchar(hex_chars[(val >> i) & 0xF]);
}
}

uint32_t timer_get_ticks(void) {
static uint32_t s_ticks = 0;
return ++s_ticks;
}

void* process_get(int pid) {
(void)pid;
return (void*)0;
}
