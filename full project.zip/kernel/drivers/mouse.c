#include "../include/isr.h"
#include "../include/pic.h"
#include "../include/pic.h"
// ============================================================================
// PS/2 Mouse Driver
// Mouse input for GUI interaction
// ============================================================================

#include "../include/mouse.h"
#include "../include/framebuffer.h"

// External functions
extern void terminal_write(const char* str);
extern void terminal_write_line(const char* str);
extern void terminal_write_hex(uint32_t value);

// Mouse state
static mouse_state_t mouse_state;
static uint8_t mouse_cycle = 0;
static int8_t mouse_packet[3];

// PS/2 ports
#define PS2_DATA    0x60
#define PS2_COMMAND 0x64

// ============================================================================
// Port I/O
// ============================================================================

static inline void outb(uint16_t port, uint8_t value) {
    __asm__ volatile("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t value;
    __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

// ============================================================================
// PS/2 Wait Functions
// ============================================================================

static void mouse_wait(uint8_t type) {
    uint32_t timeout = 100000;
    if (type == 0) {
        // Wait for output buffer
        while (timeout--) {
            if ((inb(PS2_COMMAND) & 1) == 1) {
                return;
            }
        }
    } else {
        // Wait for input buffer
        while (timeout--) {
            if ((inb(PS2_COMMAND) & 2) == 0) {
                return;
            }
        }
    }
}

// ============================================================================
// PS/2 Write
// ============================================================================

static void mouse_write(uint8_t data) {
    mouse_wait(1);
    outb(PS2_COMMAND, 0xD4);
    mouse_wait(1);
    outb(PS2_DATA, data);
}

static uint8_t mouse_read(void) {
    mouse_wait(0);
    return inb(PS2_DATA);
}

// ============================================================================
// Mouse Interrupt Handler
// ============================================================================

void mouse_handler(void) {
uint8_t status = inb(PS2_COMMAND);

if (!(status & 0x20)) {
    pic_send_eoi(12);
    return;
}

uint8_t packet = inb(PS2_DATA);

switch (mouse_cycle) {
    case 0:
        // Бит 3 в первом байте PS/2 всегда должен быть 1 для синхронизации
        if (!(packet & 0x08)) {
            break;
        }
        mouse_packet[0] = packet;
        mouse_cycle++;
        break;

    case 1:
        mouse_packet[1] = packet;
        mouse_cycle++;
        break;

    case 2:
        mouse_packet[2] = packet;
        mouse_cycle = 0;

        uint8_t b0 = (uint8_t)mouse_packet[0];
        uint8_t b1 = (uint8_t)mouse_packet[1];
        uint8_t b2 = (uint8_t)mouse_packet[2];

        // Игнорируем пакет при переполнении осей
        if (b0 & 0xC0) {
            break;
        }

        mouse_state.buttons = b0 & 0x07;

        // Корректный расчёт 9-битного знакового смещения из сырых байт
        int dx = (int)b1 - ((b0 & 0x10) ? 256 : 0);
        int dy = (int)b2 - ((b0 & 0x20) ? 256 : 0);

        mouse_state.dx = dx;
        mouse_state.dy = -dy;

        mouse_state.x += dx;
        mouse_state.y -= dy;

        // Ограничиваем координаты с запасом под размер спрайта (8x10), чтобы курсор был виден целиком
        if (mouse_state.x < 0) mouse_state.x = 0;
        if (mouse_state.x > 312) mouse_state.x = 312;
        if (mouse_state.y < 0) mouse_state.y = 0;
        if (mouse_state.y > 190) mouse_state.y = 190;
        break;
}

pic_send_eoi(12);
}

// ============================================================================
// Initialization
// ============================================================================

void mouse_init(void) {
terminal_write_line("[Mouse] Initializing PS/2 mouse...");

mouse_state.x = 160;
mouse_state.y = 100;
mouse_state.dx = 0;
mouse_state.dy = 0;
mouse_state.buttons = 0;
mouse_state.visible = 1;
mouse_cycle = 0;

while (inb(PS2_COMMAND) & 1) {
    inb(PS2_DATA);
}

mouse_wait(1);
outb(PS2_COMMAND, 0xA8);
mouse_wait(1);
outb(PS2_COMMAND, 0xAE);

mouse_wait(1);
outb(PS2_COMMAND, 0x20);
uint8_t status = mouse_read();

status = (status | 0x47) & ~0x30;

mouse_wait(1);
outb(PS2_COMMAND, 0x60);
mouse_wait(1);
outb(PS2_DATA, status);

mouse_write(0xF6);
mouse_read();

mouse_write(0xF4);
mouse_read();

register_interrupt_handler(44, (isr_t)mouse_handler);

pic_clear_mask(2);
pic_clear_mask(12);

terminal_write_line("[Mouse] PS/2 mouse initialized");
}

void mouse_set_position(int x, int y) {
mouse_state.x = x;
mouse_state.y = y;
}

void mouse_get_position(int* x, int* y) {
    if (x) *x = mouse_state.x;
    if (y) *y = mouse_state.y;
}

uint8_t mouse_get_buttons(void) {
    return mouse_state.buttons;
}

void mouse_show(void) {
    mouse_state.visible = 1;
}

void mouse_hide(void) {
    mouse_state.visible = 0;
}

void mouse_draw_cursor(void) {
    if (!mouse_state.visible || !fb) return;

    int x = mouse_state.x;
    int y = mouse_state.y;

    // Draw simple arrow cursor
    for (int i = 0; i < 16; i++) {
        fb_put_pixel(x, y + i, 15);  // White
        fb_put_pixel(x + i / 2, y + i, 15);
    }
}
