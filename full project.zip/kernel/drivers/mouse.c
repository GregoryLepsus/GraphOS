#include "../include/isr.h"
#include "../include/pic.h"
#include "../include/mouse.h"
#include "../include/framebuffer.h"

extern void terminal_write(const char* str);
extern void terminal_write_line(const char* str);
extern void terminal_write_hex(uint32_t value);

static mouse_state_t mouse_state;
static uint8_t mouse_cycle = 0;
static int8_t mouse_packet[3];

volatile uint32_t mouse_irq_count = 0;
volatile uint8_t mouse_ack_reset = 0;
volatile uint8_t mouse_ack_stream = 0;

#define PS2_DATA    0x60
#define PS2_COMMAND 0x64

static inline void outb(uint16_t port, uint8_t value) {
    __asm__ volatile("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t value;
    __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void io_wait(void) {
    outb(0x80, 0);
}

static int mouse_wait(uint8_t type) {
    uint32_t timeout = 200000;
    if (type == 0) {
        while (timeout--) {
            if (inb(PS2_COMMAND) & 1) return 1;
            io_wait();
        }
    } else {
        while (timeout--) {
            if (!(inb(PS2_COMMAND) & 2)) return 1;
            io_wait();
        }
    }
    return 0;
}

static void mouse_write_byte(uint8_t data) {
    mouse_wait(1);
    outb(PS2_COMMAND, 0xD4);
    mouse_wait(1);
    outb(PS2_DATA, data);
}

static uint8_t mouse_read_byte(void) {
    if (!mouse_wait(0)) return 0;
    return inb(PS2_DATA);
}

// Обработка одного байта PS/2
static void mouse_process_byte(uint8_t packet) {
    mouse_irq_count++;

    switch (mouse_cycle) {
        case 0:
            // Бит 3 первого байта PS/2 обязан быть 1, переполнения быть не должно
            if ((packet & 0x08) == 0 || (packet & 0xC0) != 0) {
                return;
            }
            mouse_packet[0] = (int8_t)packet;
            mouse_cycle = 1;
            break;

        case 1:
            mouse_packet[1] = (int8_t)packet;
            mouse_cycle = 2;
            break;

        case 2:
            mouse_packet[2] = (int8_t)packet;
            mouse_cycle = 0;

            uint8_t b0 = (uint8_t)mouse_packet[0];
            uint8_t b1 = (uint8_t)mouse_packet[1];
            uint8_t b2 = (uint8_t)mouse_packet[2];

            if (b0 & 0xC0) return;

            mouse_state.buttons = b0 & 0x07;

            int dx = (int)b1 - ((b0 & 0x10) ? 256 : 0);
            int dy = (int)b2 - ((b0 & 0x20) ? 256 : 0);

            mouse_state.dx = dx;
            mouse_state.dy = -dy;

            mouse_state.x += dx;
            mouse_state.y -= dy;

            if (mouse_state.x < 0) mouse_state.x = 0;
            if (mouse_state.x > 312) mouse_state.x = 312;
            if (mouse_state.y < 0) mouse_state.y = 0;
            if (mouse_state.y > 190) mouse_state.y = 190;
            break;
    }
}

// Безопасный опрос: читает ТОЛЬКО данные с битом AUX (мышь)
// Универсальный опрос мыши для физических ПК с USB Legacy
void mouse_poll(void) {
    while (inb(PS2_COMMAND) & 1) {
        uint8_t data = inb(PS2_DATA);
        mouse_process_byte(data);
    }
}

void mouse_handler(void) {
    mouse_poll();
    pic_send_eoi(12);
}

void mouse_init(void) {
    terminal_write_line("[Mouse] Initializing PS/2 mouse for Real Hardware...");

    mouse_state.x = 160;
    mouse_state.y = 100;
    mouse_state.dx = 0;
    mouse_state.dy = 0;
    mouse_state.buttons = 0;
    mouse_state.visible = 1;
    mouse_cycle = 0;
    mouse_irq_count = 0;

    int drain = 100;
    while ((inb(PS2_COMMAND) & 1) && --drain) {
        inb(PS2_DATA);
        io_wait();
    }

    mouse_wait(1);
    outb(PS2_COMMAND, 0xA8);
    io_wait();

    mouse_wait(1);
    outb(PS2_COMMAND, 0x20);
    uint8_t status = mouse_read_byte();

    status = (status | 0x03) & ~0x30;

    mouse_wait(1);
    outb(PS2_COMMAND, 0x60);
    io_wait();
    mouse_wait(1);
    outb(PS2_DATA, status);
    io_wait();

    mouse_write_byte(0xF6);
    mouse_ack_reset = mouse_read_byte();

    for (volatile int d = 0; d < 100000; d++) { io_wait(); }

    mouse_write_byte(0xF4);
    mouse_ack_stream = mouse_read_byte();

    drain = 50;
    while ((inb(PS2_COMMAND) & 1) && --drain) {
        inb(PS2_DATA);
        io_wait();
    }
    mouse_cycle = 0;

    register_interrupt_handler(44, (isr_t)mouse_handler);
    pic_clear_mask(2);
    pic_clear_mask(12);

    terminal_write_line("[Mouse] Real hardware driver ready!");
}

void mouse_set_position(int x, int y) {
    mouse_state.x = x;
    mouse_state.y = y;
}

void mouse_get_position(int* x, int* y) {
    if (x) *x = mouse_state.x;
    if (y) *y = mouse_state.y;
}

uint8_t mouse_get_buttons(void) {
    return mouse_state.buttons;
}

void mouse_show(void) {
    mouse_state.visible = 1;
}

void mouse_hide(void) {
    mouse_state.visible = 0;
}

void mouse_draw_cursor(void) {
    if (!mouse_state.visible || !fb) return;
    int x = mouse_state.x;
    int y = mouse_state.y;
    for (int i = 0; i < 16; i++) {
        fb_put_pixel(x, y + i, 15);
        fb_put_pixel(x + i / 2, y + i, 15);
    }
}
