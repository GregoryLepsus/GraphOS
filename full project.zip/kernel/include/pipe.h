#ifndef _PIPE_H
#define _PIPE_H

#include <stdint.h>
#include <stddef.h>
#include "sync.h"

#define PIPE_BUFFER_SIZE 4096

typedef struct pipe {
    char buffer[PIPE_BUFFER_SIZE];
    uint32_t read_pos;
    uint32_t write_pos;
    uint32_t count;
    mutex_t lock;
    semaphore_t not_empty;
    semaphore_t not_full;
} pipe_t;

pipe_t* pipe_create(void);
void pipe_close(pipe_t* pipe);
int pipe_write(pipe_t* pipe, const void* data, uint32_t size);
int pipe_read(pipe_t* pipe, void* data, uint32_t size);

#endif
