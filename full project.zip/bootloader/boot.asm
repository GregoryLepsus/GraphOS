; ============================================================================
; GraphOS Bootloader v0.4 (Staging Buffer 0x20000 -> 0x1000)
; ============================================================================
[BITS 16]
[ORG 0x0600]

entry:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax

    ; Стек на 575 КБ (0x8000:0xFFF0)
    mov ax, 0x8000
    mov ss, ax
    mov sp, 0xFFF0
    sti

    ; Релокация загрузчика из 0x7C00 в 0x0600
    mov si, 0x7C00
    mov di, 0x0600
    mov cx, 256
    cld
    rep movsw

    jmp 0x0000:relocated

relocated:
    mov [boot_drive], dl        ; Сохраняем привод BIOS

    ; Текстовый режим 80x25
    mov ax, 0x0003
    int 0x10

    mov si, msg_load
    call print_string

    ; Включение линии A20
    mov ax, 0x2401
    int 0x15
    jnc .a20_ok
    in al, 0x92
    or al, 2
    out 0x92, al
.a20_ok:

    call load_kernel

    mov si, msg_ok
    call print_string

    ; Переход в 32-битный защищенный режим
    cli
    lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp CODE_SEG:init_pm

; ----------------------------------------------------------------------------
print_char:
    pusha
    mov ah, 0x0E
    xor bx, bx
    int 0x10
    popa
    ret

print_string:
    pusha
.loop:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0E
    xor bx, bx
    int 0x10
    jmp .loop
.done:
    popa
    ret

; ----------------------------------------------------------------------------
SECTOR_COUNT equ 400           ; 240 секторов (~120 КБ)

load_kernel:
    ; Проверка поддержки расширений LBA (EDD)
    mov ah, 0x41
    mov bx, 0x55AA
    mov dl, [boot_drive]
    int 0x13
    jc .use_chs
    cmp bx, 0xAA55
    jne .use_chs
    test cl, 1
    jz .use_chs

    ; ========================================================================
    ; 1. Чтение LBA в буфер 0x20000 (сегмент 0x2000) вдали от 0x7C00
    ; ========================================================================
    mov cx, 25                  ; 15 пакетов по 16 секторов (8 КБ)
    mov ax, 1                   ; LBA = 1
    mov dx, 0x2000              ; Сегмент 0x2000 (физ. 0x20000 = 128 КБ)

.lba_loop:
    push ax
    push cx
    push dx

    mov [dap_segment], dx
    mov [dap_lba], ax

    mov si, dap
    mov dl, [boot_drive]
    mov ah, 0x42
    int 0x13
    jc disk_error

    mov al, '.'
    call print_char

    pop dx
    pop cx
    pop ax

    add dx, 0x0200              ; +8 КБ к сегменту
    add ax, 16                  ; +16 секторов к LBA
    dec cx
    jnz .lba_loop
    ret

    ; ========================================================================
    ; 2. Резервное чтение CHS в буфер 0x20000
    ; ========================================================================
.use_chs:
    mov ah, 0x08
    mov dl, [boot_drive]
    int 0x13
    jc .chs_defaults

    and cx, 0x3F
    mov [spt], cx
    movzx ax, dh
    inc ax
    mov [heads], ax
    jmp .chs_start

.chs_defaults:
    mov word [spt], 18
    mov word [heads], 2

.chs_start:
    mov cx, SECTOR_COUNT
    mov ax, 1
    mov dx, 0x2000              ; Сегмент 0x2000

.chs_loop:
    push ax
    push cx
    push dx

    xor dx, dx
    div word [spt]
    inc dx
    mov cl, dl

    xor dx, dx
    div word [heads]
    mov ch, al
    shl ah, 6
    or cl, ah
    mov dh, dl

    pop bx
    mov es, bx
    xor bx, bx

    mov dl, [boot_drive]
    mov ax, 0x0201
    int 0x13
    jc disk_error

    pop cx
    pop ax

    test al, 0x0F
    jnz .chs_next
    push ax
    mov al, '.'
    call print_char
    pop ax

.chs_next:
    mov bx, es
    add bx, 0x0020
    mov dx, bx
    inc ax
    dec cx
    jnz .chs_loop
    ret

disk_error:
    mov si, msg_err
    call print_string
    jmp $

; ----------------------------------------------------------------------------
[BITS 32]
init_pm:
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    mov esp, 0x90000

    ; Переносим ядро из промежуточного буфера 0x20000 в целевую область 0x1000
    mov esi, 0x20000
    mov edi, 0x1000
    mov ecx, (SECTOR_COUNT * 512) / 4
    cld
    rep movsd

    call 0x1000                 ; Запуск ядра GraphOS
    jmp $

; ----------------------------------------------------------------------------
[BITS 16]
align 4
gdt_start:
gdt_null:
    dd 0, 0
gdt_code:
    dw 0xFFFF, 0
    db 0, 10011010b, 11001111b, 0
gdt_data:
    dw 0xFFFF, 0
    db 0, 10010010b, 11001111b, 0
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

align 4
dap:
    db 0x10, 0
    dw 16                       ; 16 секторов за вызов
    dw 0
dap_segment:
    dw 0x2000                   ; 0x20000
dap_lba:
    dd 1
    dd 0

boot_drive  db 0
spt         dw 18
heads       dw 2

msg_load    db 'Loading: ', 0
msg_ok      db ' OK', 0x0D, 0x0A, 0
msg_err     db ' Disk error!', 0x0D, 0x0A, 0

times 510-($-$$) db 0
dw 0xAA55
