; ============================================================================
; GraphOS Bootloader (Relocating + Multi-Sector CHS/LBA)
; ============================================================================
[BITS 16]
[ORG 0x0600]

entry:
    ; BIOS загружает загрузчик по адресу 0x7C00.
    ; Копируем 512 байт в 0x0600, чтобы ядро по адресу 0x1000+ не затерло наш код.
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    mov si, 0x7C00
    mov di, 0x0600
    mov cx, 256
    cld
    rep movsw

    jmp 0x0000:relocated

relocated:
    ; Сохраняем привод, переданный BIOS в DL (0x00 для Floppy, 0x80 для HDD)
    mov [boot_drive], dl

    ; Стек в верхней границе базовой памяти (0x9000:0xFFF0)
    mov ax, 0x9000
    mov ss, ax
    mov sp, 0xFFF0

    call clear_screen
    mov si, msg_boot
    call print_string

    call enable_a20

    mov si, msg_loading
    call print_string
    call load_kernel

    call enter_protected_mode
    jmp $

; ----------------------------------------------------------------------------
clear_screen:
    pusha
    mov ax, 0x0003
    int 0x10
    popa
    ret

; ----------------------------------------------------------------------------
print_string:
    pusha
.loop:
    lodsb
    test al, al
    jz .done
    mov ah, 0x0E
    xor bx, bx
    int 0x10
    jmp .loop
.done:
    popa
    ret

; ----------------------------------------------------------------------------
enable_a20:
    pusha
    mov ax, 0x2401
    int 0x15
    jnc .done
    in al, 0x92
    or al, 2
    out 0x92, al
.done:
    popa
    ret

; ----------------------------------------------------------------------------
SECTOR_COUNT equ 240   ; 240 секторов (~120 КБ, с запасом под kernel.bin 105 КБ)

load_kernel:
    pusha

    cmp byte [boot_drive], 0x80
    jae .read_hdd

    ; Чтение с дискеты (по 1 сектору с трансляцией CHS)
    mov ax, 1           ; LBA 1 (сектор 2 диска)
    mov cx, SECTOR_COUNT
    mov dx, 0x0100      ; Сегмент 0x0100 -> физический адрес 0x1000
    mov es, dx
    xor bx, bx

.floppy_loop:
    push ax
    push cx
    mov bp, 3           ; 3 попытки чтения на сектор

.retry:
    push bp
    push ax

    ; LBA -> CHS
    xor dx, dx
    mov di, 18
    div di              ; AX = LBA / 18, DX = LBA % 18
    inc dl
    mov cl, dl          ; Sector

    xor dx, dx
    mov di, 2
    div di
    mov ch, al          ; Cylinder
    mov dh, dl          ; Head

    mov dl, [boot_drive]
    mov ax, 0x0201      ; Читать 1 сектор
    xor bx, bx
    int 0x13
    jnc .sector_ok

    ; Сброс контроллера диска при ошибке
    xor ax, ax
    mov dl, [boot_drive]
    int 0x13

    pop ax
    pop bp
    dec bp
    jnz .retry
    jmp .disk_error

.sector_ok:
    pop ax
    pop bp

    ; Сдвигаем сегмент ES на 512 байт (0x20 параграфов)
    mov ax, es
    add ax, 0x0020
    mov es, ax

    pop cx
    pop ax
    inc ax
    dec cx
    jnz .floppy_loop
    jmp .read_done

.read_hdd:
    mov dl, [boot_drive]
    mov si, disk_address_packet
    mov ah, 0x42
    int 0x13
    jc .disk_error

.read_done:
    mov si, msg_ok
    call print_string
    popa
    ret

.disk_error:
    mov si, msg_disk_error
    call print_string
    jmp $

; ----------------------------------------------------------------------------
enter_protected_mode:
    cli
    lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp CODE_SEG:init_pm

[BITS 32]
init_pm:
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    mov ebp, 0x90000
    mov esp, ebp

    call KERNEL_OFFSET
    jmp $

; ----------------------------------------------------------------------------
align 4
gdt_start:
gdt_null:
    dd 0x0, 0x0
gdt_code:
    dw 0xFFFF, 0x0
    db 0x0, 10011010b, 11001111b, 0x0
gdt_data:
    dw 0xFFFF, 0x0
    db 0x0, 10010010b, 11001111b, 0x0
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

KERNEL_OFFSET equ 0x1000

align 4
disk_address_packet:
    db 0x10
    db 0
    dw SECTOR_COUNT
    dw 0x1000
    dw 0x0000
    dq 1

boot_drive      db 0
msg_boot        db 'GraphOS Bootloader v0.1', 0x0D, 0x0A, 0
msg_loading     db 'Loading kernel...', 0x0D, 0x0A, 0
msg_ok          db 'OK', 0x0D, 0x0A, 0
msg_disk_error  db 'Disk read error!', 0x0D, 0x0A, 0

times 510-($-$$) db 0
dw 0xAA55
